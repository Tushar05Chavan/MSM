import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get_core/src/smart_management.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:msm_unify/App/common/color_constant.dart';

import 'App/Screens/Authentication/Login/Views/login_screen.dart';
import 'App/common/Model/controller_binding.dart';

void main() {
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: kColorPrimary, // status bar color
      statusBarIconBrightness: Brightness.dark));
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
        designSize: const Size(360, 690),
        builder: (BuildContext context, child) {
          return GetMaterialApp(
            initialBinding: ControllerBindings(),
            debugShowCheckedModeBanner: false,
            smartManagement: SmartManagement.full,
            title: 'MSM UNIFY',
            theme: ThemeData(primarySwatch: Colors.blue, useMaterial3: true),
            home: const LoginScreen(),
          );
        });
  }
}
