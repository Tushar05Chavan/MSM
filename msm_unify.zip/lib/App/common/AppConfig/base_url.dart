class BaseUrl{
  static const String baseUrl = 'https://unify-qa-api.azurewebsites.net';
}