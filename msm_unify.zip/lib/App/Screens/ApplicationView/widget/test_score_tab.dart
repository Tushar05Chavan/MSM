import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:msm_unify/App/common/AppConfig/support_section.dart';
import 'package:msm_unify/App/common/color_constant.dart';
import 'package:msm_unify/model/responseModek/application_view_response_model.dart';

import '../../ApplicationProgramStudent/widget/application_program_personal_info_tab.dart';

class TestScoreTab extends StatefulWidget {
  final ApplicationViewResponseModel data;

  const TestScoreTab({super.key, required this.data});
  @override
  _TestScoreTabState createState() => _TestScoreTabState();
}

class _TestScoreTabState extends State<TestScoreTab> {
  final _date = TextEditingController();
  final _listening = TextEditingController();
  final _reading = TextEditingController();
  final _writing = TextEditingController();
  final _speaking = TextEditingController();
  final _overAll = TextEditingController();

  final DateFormat formatter = DateFormat('dd-MM-yyyy');

  String? _selectedExam;
  final List<String> _exam = [
    'IELTS',
    'PTE',
    'ESOL',
    'Not Applicable',
    'Oxford Online'
  ];

  String? _otherExam;
  final List<String> _exams = [
    'None',
    'ACT',
    'GMAT',
    'GRE',
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(
              height: 15,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'English',
                  style: TextStyle(
                    color: kNavy,
                    fontSize: 15,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(
                  width: 5,
                ),
                GestureDetector(
                  onTap: () {
                    showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return StatefulBuilder(
                          builder: (BuildContext context,
                              void Function(void Function()) setState) {
                            return SimpleDialog(
                              shape: ContinuousRectangleBorder(
                                  side: const BorderSide(color: kRed),
                                  borderRadius: BorderRadius.circular(15)),
                              children: [
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10),
                                  child: Column(
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          const Flexible(
                                            child: Text(
                                              'Test Score',
                                              style: TextStyle(
                                                  color: kNavy,
                                                  fontFamily: 'Poppins',
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ),
                                          Flexible(
                                            child: InkWell(
                                              onTap: () {
                                                Get.back();
                                              },
                                              child: Container(
                                                height: Get.height * 0.03,
                                                width: Get.width * 0.08,
                                                decoration: BoxDecoration(
                                                    color: kRed,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5)),
                                                child: const Icon(
                                                  Icons.close,
                                                  color: Colors.white,
                                                  size: 25,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      SizedBox(
                                        height: Get.height * 0.02,
                                      ),
                                      Row(
                                        children: const [
                                          Text(
                                            'English Exam',
                                            style: TextStyle(
                                                color: kNavy,
                                                fontFamily: 'Poppins',
                                                fontSize: 16,
                                                fontWeight: FontWeight.bold),
                                          )
                                        ],
                                      ),
                                      SizedBox(
                                        height: Get.height * 0.02,
                                      ),
                                      DropdownButtonHideUnderline(
                                        child: DropdownButtonFormField(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            hint:
                                                const Text("English Exam Type"),
                                            decoration: InputDecoration(
                                              label: const Text(
                                                'Exam Type',
                                              ),
                                              labelStyle: const TextStyle(
                                                fontFamily: 'Roboto',
                                                color: kGrey4,
                                              ),
                                              // enabledBorder: OutlineInputBorder(
                                              //     borderRadius: BorderRadius.circular(15),
                                              //     borderSide: BorderSide(
                                              //         color: kGrey4, width: 1)),
                                              //labelText: 'Exam Type',
                                              focusedBorder: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                  borderSide: const BorderSide(
                                                      color: kGrey, width: 2)),
                                              border: OutlineInputBorder(
                                                  borderSide: const BorderSide(
                                                      color: kGrey4, width: 1),
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          15)),
                                            ),
                                            value: _selectedExam,
                                            items: _exam.map((exam) {
                                              return DropdownMenuItem(
                                                  value: exam,
                                                  child: Text(
                                                    exam,
                                                    style: const TextStyle(
                                                        color: kGrey4,
                                                        fontFamily: "Roboto",
                                                        fontSize: 13),
                                                  ));
                                            }).toList(),
                                            onChanged: (newValue) {
                                              setState(() {
                                                _selectedExam =
                                                    newValue as String?;
                                              });
                                            }),
                                      ),
                                      SizedBox(
                                        height: Get.height * 0.02,
                                      ),
                                      TextFormField(
                                        controller: _date,
                                        cursorColor: kRed,
                                        decoration: InputDecoration(
                                            suffixIcon: IconButton(
                                              icon: const Icon(Icons.today),
                                              onPressed: () async {
                                                DateTime date = DateTime(1900);
                                                FocusScope.of(context)
                                                    .requestFocus(FocusNode());

                                                date = (await showDatePicker(
                                                    context: context,
                                                    initialDate: DateTime.now(),
                                                    firstDate: DateTime(1900),
                                                    lastDate: DateTime.now()))!;
                                                _date.text =
                                                    formatter.format(date);
                                              },
                                            ),
                                            focusedBorder: OutlineInputBorder(
                                                borderRadius:
                                                    BorderRadius.circular(15),
                                                borderSide: const BorderSide(
                                                  color: Colors.black,
                                                )),
                                            hintStyle: TextStyle(
                                                color: Colors.black
                                                    .withOpacity(0.2),
                                                fontFamily: 'Roboto'),
                                            hintText: 'Exam Date',
                                            label: const Text('DD/MM/YYYY'),
                                            labelStyle: const TextStyle(
                                              fontFamily: 'Roboto',
                                              color: kGrey4,
                                            ),
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(15),
                                            )),
                                      ),
                                      SizedBox(
                                        height: Get.height * 0.02,
                                      ),
                                      CommonTextField(
                                        control: _listening,
                                        title: 'Listening',
                                        subtitle: 'Listening',
                                      ),
                                      SizedBox(
                                        height: Get.height * 0.02,
                                      ),
                                      CommonTextField(
                                        control: _reading,
                                        title: 'Reading',
                                        subtitle: 'Reading',
                                      ),
                                      SizedBox(
                                        height: Get.height * 0.02,
                                      ),
                                      CommonTextField(
                                        control: _writing,
                                        title: 'Writing',
                                        subtitle: 'Writing',
                                      ),
                                      SizedBox(
                                        height: Get.height * 0.02,
                                      ),
                                      CommonTextField(
                                        control: _speaking,
                                        title: 'Speaking',
                                        subtitle: 'Speaking',
                                      ),
                                      SizedBox(
                                        height: Get.height * 0.02,
                                      ),
                                      CommonTextField(
                                        control: _overAll,
                                        title: 'Overall',
                                        subtitle: 'Overall',
                                      ),
                                      SizedBox(
                                        height: Get.height * 0.05,
                                      ),
                                      Row(
                                        children: const [
                                          Text(
                                            'Other Exam',
                                            style: TextStyle(
                                                color: kNavy,
                                                fontFamily: 'Poppins',
                                                fontSize: 16,
                                                fontWeight: FontWeight.bold),
                                          )
                                        ],
                                      ),
                                      SizedBox(
                                        height: Get.height * 0.02,
                                      ),
                                      DropdownButtonHideUnderline(
                                        child: DropdownButtonFormField(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            hint: const Text("Other Exam"),
                                            decoration: InputDecoration(
                                              border: OutlineInputBorder(
                                                  borderSide: const BorderSide(
                                                      color: kGrey4, width: 1),
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          15)),
                                              label: const Text('Other Exam'),
                                              labelStyle: const TextStyle(
                                                fontFamily: 'Roboto',
                                                color: kGrey4,
                                              ),
                                              focusedBorder: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                  borderSide: const BorderSide(
                                                      color: kGrey, width: 2)),
                                            ),
                                            value: _otherExam,
                                            items: _exams.map((exams) {
                                              return DropdownMenuItem(
                                                  value: exams,
                                                  child: Text(
                                                    exams,
                                                    style: const TextStyle(
                                                        color: kGrey4,
                                                        fontFamily: "Roboto",
                                                        fontSize: 13),
                                                  ));
                                            }).toList(),
                                            onChanged: (newValue) {
                                              setState(() {
                                                _otherExam =
                                                    newValue as String?;
                                              });
                                            }),
                                      ),
                                      SizedBox(
                                        height: Get.height * 0.05,
                                      ),
                                      GestureDetector(
                                        onTap: () {},
                                        child: Container(
                                          width: Get.width * 0.30,
                                          height: Get.height * 0.04,
                                          decoration: BoxDecoration(
                                            color: kRed,
                                            borderRadius:
                                                BorderRadius.circular(20),
                                          ),
                                          child: const Center(
                                              child: Text(
                                            'Update',
                                            style: TextStyle(
                                                fontFamily: 'Roboto',
                                                color: Colors.white),
                                          )),
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                              ],
                            );
                          },
                        );
                      },
                    );
                  },
                  child: Container(
                    height: Get.height * 0.04,
                    width: Get.width * 0.09,
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.black),
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(8),
                          bottomRight: Radius.circular(8),
                          topRight: Radius.circular(8),
                        )),
                    child: const Icon(
                      Icons.edit_outlined,
                      color: Colors.black,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 15,
            ),
            Container(
              padding: const EdgeInsets.all(10),
              height: Get.height * 0.12,
              width: Get.width * 0.80,
              decoration: BoxDecoration(
                  color: kGrey6, borderRadius: BorderRadius.circular(10)),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Exam',
                    style: TextStyle(
                        color: Color(0xff79747E),
                        fontFamily: 'Poppins',
                        fontSize: 16),
                  ),
                  Text(
                    '${widget.data.testScore!.englishExamName}',
                    style: const TextStyle(
                        color: Color(0xff192A3E),
                        fontFamily: 'Poppins',
                        fontSize: 16),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 15,
            ),
            Container(
              padding: const EdgeInsets.all(10),
              height: Get.height * 0.12,
              width: Get.width * 0.80,
              decoration: BoxDecoration(
                  color: kGrey6, borderRadius: BorderRadius.circular(10)),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Exam Date',
                    style: TextStyle(
                        color: Color(0xff79747E),
                        fontFamily: 'Poppins',
                        fontSize: 16),
                  ),
                  Text(
                    '${widget.data.testScore!.englishExamDate}',
                    style: const TextStyle(
                        color: Color(0xff192A3E),
                        fontFamily: 'Poppins',
                        fontSize: 16),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 15,
            ),
            Container(
              padding: const EdgeInsets.all(10),
              height: Get.height * 0.12,
              width: Get.width * 0.80,
              decoration: BoxDecoration(
                  color: kGrey6, borderRadius: BorderRadius.circular(10)),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Overall',
                    style: TextStyle(
                        color: Color(0xff79747E),
                        fontFamily: 'Poppins',
                        fontSize: 16),
                  ),
                  Text(
                    '${widget.data.testScore!.englishScoreOverall}',
                    style: const TextStyle(
                        color: Color(0xff192A3E),
                        fontFamily: 'Poppins',
                        fontSize: 16),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 15,
            ),
            Container(
              padding: EdgeInsets.all(10),
              height: Get.height * 0.12,
              width: Get.width * 0.80,
              decoration: BoxDecoration(
                  color: kGrey6, borderRadius: BorderRadius.circular(10)),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Reading',
                    style: TextStyle(
                        color: Color(0xff79747E),
                        fontFamily: 'Poppins',
                        fontSize: 16),
                  ),
                  Text(
                    '${widget.data.testScore!.englishScoreR}',
                    style: const TextStyle(
                        color: Color(0xff192A3E),
                        fontFamily: 'Poppins',
                        fontSize: 16),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 15,
            ),
            Container(
              padding: const EdgeInsets.all(10),
              height: Get.height * 0.12,
              width: Get.width * 0.80,
              decoration: BoxDecoration(
                  color: kGrey6, borderRadius: BorderRadius.circular(10)),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Writing',
                    style: TextStyle(
                        color: Color(0xff79747E),
                        fontFamily: 'Poppins',
                        fontSize: 16),
                  ),
                  Text(
                    '${widget.data.testScore!.englishScoreW}',
                    style: const TextStyle(
                        color: Color(0xff192A3E),
                        fontFamily: 'Poppins',
                        fontSize: 16),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 15,
            ),
            Container(
              padding: const EdgeInsets.all(10),
              height: Get.height * 0.12,
              width: Get.width * 0.80,
              decoration: BoxDecoration(
                  color: kGrey6, borderRadius: BorderRadius.circular(10)),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Listening',
                    style: TextStyle(
                        color: Color(0xff79747E),
                        fontFamily: 'Poppins',
                        fontSize: 16),
                  ),
                  Text(
                    '${widget.data.testScore!.englishScoreL}',
                    style: const TextStyle(
                        color: Color(0xff192A3E),
                        fontFamily: 'Poppins',
                        fontSize: 16),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 15,
            ),
            Container(
              padding: const EdgeInsets.all(10),
              height: Get.height * 0.12,
              width: Get.width * 0.80,
              decoration: BoxDecoration(
                  color: kGrey6, borderRadius: BorderRadius.circular(10)),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Speaking',
                    style: TextStyle(
                        color: Color(0xff79747E),
                        fontFamily: 'Poppins',
                        fontSize: 16),
                  ),
                  Text(
                    '${widget.data.testScore!.englishScoreS}',
                    style: const TextStyle(
                        color: Color(0xff192A3E),
                        fontFamily: 'Poppins',
                        fontSize: 16),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 25,
            ),
            supportSection(),
          ],
        ),
      ),
    );
  }
}
