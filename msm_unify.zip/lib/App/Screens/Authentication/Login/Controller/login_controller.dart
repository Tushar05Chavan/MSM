import 'dart:convert';
import 'dart:developer';
import 'package:encrypt/encrypt.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:msm_unify/App/AppData/app_data.dart';
import 'package:msm_unify/App/common/AppConfig/base_url.dart';

class LoginController extends GetxController {
  var userInputEmail = ''.obs;
  var userInputPassword = ''.obs;

  @override
  void onInit() {
    super.onInit();
  }

  Future<void> loginCredentials() async {
    final keys = Key.fromUtf8('123456\$#@\$^@1ERF');
    final iv = IV.fromUtf8('123456\$#@\$^@1ERF');
    final encrypter = Encrypter(AES(keys, mode: AESMode.cbc, padding: 'PKCS7'));
    var hassPassword = encrypter.encrypt(userInputPassword.value, iv: iv);
    var headers = {
      'Referer': 'localhost:4200',
      'Content-Type': 'application/json'
    };
    try {
      var request = http.Request(
          'POST', Uri.parse('${BaseUrl.baseUrl}/Authentication/Login'));
      request.body = json.encode({
        "username": userInputEmail.value,
        "Password": hassPassword.base64,
        "LoginType": "0",
        "ip": "0.0.0.0"
      });
      request.headers.addAll(headers);

      var response = await request.send();

      if (response.statusCode == 200) {
        final respStr = await response.stream.bytesToString();
        Get.find<AppData>().userData(jsonDecode(respStr));
      } else {}
    } catch (e) {
      log(e.toString());
    }
  }
}
