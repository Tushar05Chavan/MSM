import 'dart:developer';

import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:msm_unify/Api/api_response.dart';
import 'package:msm_unify/App/Screens/AddStudent/add_student_screen.dart';
import 'package:msm_unify/App/Screens/ApplicationLists/application_list_screen.dart';
import 'package:msm_unify/App/Screens/ApplicationView/application_view.dart';
import 'package:msm_unify/App/Screens/Dashboard/controller/dashboard_controller.dart';
import 'package:msm_unify/App/Screens/ProgramDetail/program_details_screen.dart';
import 'package:msm_unify/model/responseModek/country_response_model.dart';
import 'package:msm_unify/model/responseModek/for_dashboard_response_model.dart';
import 'package:msm_unify/model/responseModek/get_tiles_response_model.dart';
import 'package:msm_unify/model/responseModek/new_program_arrivals_enhance_response_model.dart';
import 'package:msm_unify/model/responseModek/news_response_model.dart' as ns;
import 'package:msm_unify/model/responseModek/recent_applications_new_enhance_response_model.dart';
import 'package:msm_unify/viewModel/country_view_model.dart';
import 'package:msm_unify/viewModel/for_dashboard_view_model.dart';
import 'package:msm_unify/viewModel/get_tiles_view_model.dart';
import 'package:msm_unify/viewModel/new_program_arrivals_enhance_view_model.dart';
import 'package:msm_unify/viewModel/news_view_model.dart';
import 'package:msm_unify/viewModel/recent_application_new_enhance_view_model.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../../constant/static_data.dart';
import '../../../common/AppConfig/separator.dart';
import '../../../common/AppConfig/support_section.dart';
import '../../../common/color_constant.dart';
import '../../FeeWaierLists/fee_waier_list.dart';

class DashboardBody extends StatefulWidget {
  const DashboardBody({Key? key}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _DashboardBodyState createState() => _DashboardBodyState();
}

class _DashboardBodyState extends State<DashboardBody> {
  final PageController _pageController = PageController(initialPage: 0);
  final FavouriteListViewModel _favouriteListViewModel =
      Get.put(FavouriteListViewModel());
  final NewProgramArrivalsEnhanceViewModel _newProgramArrivalsEnhanceViewModel =
      Get.put(NewProgramArrivalsEnhanceViewModel());
  final NewsViewModel _newsViewModel = Get.put(NewsViewModel());
  final RecentApplicationsNewEnhanceViewModel
      _recentApplicationsNewEnhanceViewModel =
      Get.put(RecentApplicationsNewEnhanceViewModel());
  final ForDashboardViewModel _forDashboardViewModel =
      Get.put(ForDashboardViewModel());

  String? _selectedCountry;
  String? _selectedPartner;
  final List<String> _country = [
    'Yemen',
    'India',
    "USA",
    "Afghanistan",
    "Argentina"
  ];

  final List<String> _partner = ['All', 'GMO', 'MSM Unify'];
  final CountryViewModel _countryViewModel = Get.put(CountryViewModel());

  List<CountryResponseModel> countryS = [];
  Future<void> getCountry() async {
    await _countryViewModel.countryViewModel();
    List<CountryResponseModel> response = _countryViewModel.apiResponse.data;
    response.forEach((element) {
      countryS.add(element);
    });
    setState(() {});
  }

  @override
  void initState() {
    getCountry();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.all(15),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Search program to apply",
                  style: TextStyle(
                      color: Color(0xff555555),
                      fontFamily: 'Roboto',
                      fontSize: 11),
                ),
                const SizedBox(
                  height: 5,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      height: Get.height * 0.060,
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: kGrey4),
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton(
                            borderRadius: BorderRadius.circular(5),
                            hint: const Text("Nationalities"),
                            value: _selectedCountry,
                            items: countryS.map((country) {
                              return DropdownMenuItem(
                                  value: country.countryName.toString(),
                                  child: Text(
                                    country.countryName.toString(),
                                    style: const TextStyle(
                                        color: kGrey4,
                                        fontFamily: "Roboto",
                                        fontSize: 13),
                                  ));
                            }).toList(),
                            onChanged: (newValue) {
                              setState(() {
                                _selectedCountry = newValue as String?;
                              });
                            }),
                      ),
                    ),
                    Flexible(
                      child: SizedBox(
                        height: Get.height * 0.060,
                        width: Get.width * 0.55,
                        child: TextFormField(
                          decoration: InputDecoration(
                              hintStyle: TextStyle(
                                  color: Colors.black.withOpacity(0.2)),
                              hintText: 'What do you Want to study?',
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                              )),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    SizedBox(
                      height: Get.height * 0.060,
                      width: Get.width * 0.30,
                      child: TextFormField(
                        decoration: InputDecoration(
                            hintStyle:
                                TextStyle(color: Colors.black.withOpacity(0.2)),
                            hintText: 'Destination',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                            )),
                      ),
                    ),
                    Container(
                      height: Get.height * 0.060,
                      width: Get.width * 0.35,
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: kGrey4),
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton(
                            borderRadius: BorderRadius.circular(5),
                            hint: const Text("All"),
                            value: _selectedPartner,
                            items: _partner.map((partner) {
                              return DropdownMenuItem(
                                  value: partner,
                                  child: Text(
                                    partner,
                                    style: const TextStyle(
                                        color: kGrey4,
                                        fontFamily: "Roboto",
                                        fontSize: 13),
                                  ));
                            }).toList(),
                            onChanged: (newValue) {
                              setState(() {
                                _selectedPartner = newValue as String?;
                              });
                            }),
                      ),
                    ),
                    Container(
                      height: Get.height * 0.060,
                      width: Get.width * 0.25,
                      decoration: BoxDecoration(
                          color: kNavy,
                          borderRadius: BorderRadius.circular(10)),
                      child: const Center(
                        child: Text(
                          "Search",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontFamily: 'Roboto',
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(
            height: 10,
          ),

          ///banners
          Container(
            height: 180,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15),
            ),
            child: CarouselSlider(
              options: CarouselOptions(
                aspectRatio: 2.1,
                viewportFraction: 1.0,
              ),
              items: List.generate(
                  banners.length,
                  (index) => Container(
                        width: Get.width,
                        margin: const EdgeInsets.symmetric(horizontal: 5.0),
                        decoration: BoxDecoration(
                            color: Colors.amber,
                            image: DecorationImage(
                                fit: BoxFit.cover,
                                image: AssetImage(banners[index])),
                            borderRadius: BorderRadius.circular(20)),
                      )),
            ),
          ),
          const SizedBox(height: 20),
          Container(
            width: Get.width,
            padding: EdgeInsets.all(Get.width * 0.03),
            margin: EdgeInsets.symmetric(horizontal: Get.width * 0.03),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(15),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.2),
                  blurRadius: 10,
                  spreadRadius: 10,
                )
              ],
            ),
            child: Column(
              children: [
                const SizedBox(height: 10),
                const Text(
                  'FeeWaierLists Fee Waivers',
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    color: kGrey,
                  ),
                ),
                GetBuilder<ForDashboardViewModel>(
                  builder: (controller) {
                    if (controller.apiResponse.status == Status.COMPLETE) {
                      List<ForDashboardResponseModel> forDashboardData =
                          controller.apiResponse.data;
                      return ListView.separated(
                        separatorBuilder: (context, index) =>
                            const SizedBox(height: 10),
                        itemCount: forDashboardData.length,
                        physics: const NeverScrollableScrollPhysics(),
                        padding: const EdgeInsets.only(top: 10),
                        shrinkWrap: true,
                        itemBuilder: (context, index) => Container(
                          width: Get.width,
                          height: 60,
                          padding: EdgeInsets.symmetric(
                              horizontal: Get.width * 0.03),
                          decoration: BoxDecoration(
                            color: kPinkLight,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                width: 130,
                                height: 50,
                                decoration: BoxDecoration(
                                    image: DecorationImage(
                                        fit: BoxFit.contain,
                                        image: NetworkImage(
                                            '${"https://appmsmunifyprod.blob.core.windows.net/docs/files/institution/"}${forDashboardData[index].instLogoPath}'))),
                              ),
                              Text(
                                '${forDashboardData[index].waiverPer}${'%'}',
                                style: const TextStyle(
                                  fontFamily: 'Poppins',
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                  color: kRed,
                                ),
                              )
                            ],
                          ),
                        ),
                      );
                    } else {
                      if (controller.apiResponse.status == Status.ERROR) {
                        return const Center(
                          child: CircularProgressIndicator(),
                        );
                      }
                      return const Center(
                        child: CircularProgressIndicator(),
                      );
                    }
                  },
                ),
                const SizedBox(
                  height: 15,
                ),
                GestureDetector(
                  onTap: () {
                    Get.to(const FeeWaierList());
                  },
                  child: const Text(
                    'View More',
                    style: TextStyle(
                      // fontFamily: 'Roboto',
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: kRed,
                    ),
                  ),
                )
              ],
            ),
          ),
          const SizedBox(height: 20),

          ///GridView
          GetBuilder<FavouriteListViewModel>(
            builder: (controller) {
              if (controller.apiResponse.status == Status.COMPLETE) {
                List<TilesResponseModel> mm = controller.apiResponse.data;
                return Container(
                  width: Get.width,
                  // height: Get.height / 2,
                  padding: EdgeInsets.zero,
                  margin: EdgeInsets.symmetric(horizontal: Get.width * 0.03),
                  child: GridView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: mm.length,
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 10,
                      childAspectRatio: 1,
                      crossAxisSpacing: 10,
                    ),
                    shrinkWrap: true,
                    itemBuilder: (context, index) => Container(
                      padding: const EdgeInsets.all(15),
                      decoration: BoxDecoration(
                        color: data[index]['color'],
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Text(
                            '${mm[index].name}',
                            style: const TextStyle(
                              fontFamily: 'Poppins',
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: kGrey,
                            ),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                '${mm[index].noOfItem}',
                                style: const TextStyle(
                                  fontFamily: 'Poppins',
                                  fontSize: 30,
                                  fontWeight: FontWeight.w700,
                                  color: kDarkBlue,
                                ),
                              ),
                              data[index]['increasing']
                                  ? const CircleAvatar(
                                      radius: 15,
                                      backgroundImage: AssetImage(
                                          'assets/images/arrowupgreen.png'),
                                    )
                                  : const CircleAvatar(
                                      radius: 15,
                                      backgroundImage: AssetImage(
                                          'assets/images/arrowdownred.png'),
                                    )
                            ],
                          ),
                          // data[index]['increasing']
                          //     ? Align(
                          //         alignment: Alignment.bottomRight,
                          //         child: Text(
                          //           '${data[index]['percentage']}',
                          //           style: const TextStyle(
                          //             fontFamily: 'Poppins',
                          //             fontSize: 16,
                          //             fontWeight: FontWeight.w600,
                          //             color: kNoeGreen,
                          //           ),
                          //         ))
                          //     : Align(
                          //         alignment: Alignment.bottomRight,
                          //         child: Text(
                          //           '-${data[index]['percentage']}',
                          //           style: const TextStyle(
                          //             fontFamily: 'Poppins',
                          //             fontSize: 16,
                          //             fontWeight: FontWeight.w600,
                          //             color: kRed,
                          //           ),
                          //         )),
                        ],
                      ),
                    ),
                  ),
                );
              } else {
                if (controller.apiResponse.status == Status.ERROR) {
                  return const Text('No Data Found');
                }
                return const Center(child: CircularProgressIndicator());
              }
            },
          ),

          const SizedBox(height: 20),

          Padding(
            padding: EdgeInsets.all(Get.width * 0.03),
            child: const MySeparator(),
          ),

          ///Application
          Container(
            width: Get.width,
            padding: EdgeInsets.all(Get.width * 0.03),
            margin: EdgeInsets.symmetric(horizontal: Get.width * 0.03),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(15),
              boxShadow: [
                BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    blurRadius: 15,
                    offset: const Offset(0.0, 20.0))
              ],
            ),
            child: Column(
              children: [
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'FeeWaierLists',
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                        color: kDarkBlue,
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        Get.to(AddStudentScreen());
                      },
                      child: Container(
                        padding: EdgeInsets.all(5),
                        height: 30,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: kGreen),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SvgPicture.asset(
                              'assets/icons/plus-black.svg',
                              height: 12,
                              width: 12,
                            ),
                            const SizedBox(
                              width: 5,
                            ),
                            const Text('New Application'),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                GetBuilder<RecentApplicationsNewEnhanceViewModel>(
                  builder: (controller) {
                    if (controller.apiResponse.status == Status.COMPLETE) {
                      List<RecentApplicationsNewEnhanceResponseModel>
                          recentData = controller.apiResponse.data;
                      return ListView.separated(
                        separatorBuilder: (context, index) =>
                            const SizedBox(height: 10),
                        itemCount: 3,
                        physics: const NeverScrollableScrollPhysics(),
                        padding: const EdgeInsets.only(top: 10),
                        shrinkWrap: true,
                        itemBuilder: (context, index1) => Container(
                          width: Get.width,
                          padding: EdgeInsets.all(Get.width * 0.03),
                          decoration: BoxDecoration(
                            color: kGrey1,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    "${recentData[index1].firstName} ${recentData[index1].middleName} ${recentData[index1].lastName}",
                                    style: const TextStyle(
                                      fontFamily: 'Poppins',
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600,
                                      color: kDarkGrey,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  GestureDetector(
                                      onTap: () {
                                        Get.to(ApplicationViewScreen(
                                          applicationId:
                                              recentData[index1].applicationId,
                                        ));
                                      },
                                      child: SvgPicture.asset(
                                          'assets/icons/Moredetils.svg'))
                                ],
                              ),
                              const SizedBox(height: 10),
                              Text(
                                '${recentData[index1].instName}',
                                style: const TextStyle(
                                  fontFamily: 'Poppins',
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: kDarkGrey,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 10),
                              Text(
                                '${recentData[index1].programName}',
                                style: const TextStyle(
                                  fontFamily: 'Poppins',
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: kDarkGrey,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 10),
                              Container(
                                height: 26,
                                width: Get.width * 0.3,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(5),
                                    color: kOrange),
                                child: Center(
                                  child: Text(
                                    '${recentData[index1].applicationStatusName}',
                                    style: const TextStyle(
                                      fontFamily: 'Poppins',
                                      fontSize: 10,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(
                                height: 15,
                              ),
                              GestureDetector(
                                onTap: () {
                                  Get.to(ApplicationListScreen(
                                    recentData: recentData,
                                  ));
                                },
                                child: const Text(
                                  'View More',
                                  style: TextStyle(
                                    // fontFamily: 'Roboto',
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                    color: kRed,
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                      );
                    } else {
                      if (controller.apiResponse.status == Status.ERROR) {
                        return Text("No Data Found");
                      }
                      return const Center(child: CircularProgressIndicator());
                    }
                  },
                ),
              ],
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          const Text(
            'News & Announcement',
            style: TextStyle(
              fontFamily: 'Poppins',
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: kGrey,
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          // ListView.separated(
          //   padding: EdgeInsets.zero,
          //   separatorBuilder: (context, index) => const SizedBox(
          //     height: 10,
          //   ),
          //   itemCount: 5,
          //   shrinkWrap: true,
          //   physics: const NeverScrollableScrollPhysics(),
          //   itemBuilder: (context, index) => Container(
          //     margin: EdgeInsets.symmetric(horizontal: Get.width * 0.03),
          //     padding: EdgeInsets.all(Get.width * 0.03),
          //     decoration: BoxDecoration(
          //       borderRadius: BorderRadius.circular(10),
          //       color: Colors.white,
          //       boxShadow: [
          //         BoxShadow(
          //           color: Colors.grey.withOpacity(0.3),
          //           blurRadius: 10,
          //         ),
          //       ],
          //     ),
          //     child: Column(
          //       children: [
          //         Html(
          //             data:
          //                 'Top Scholarships for International Students Studying in Canada'),
          //         // Text(
          //         //   '${parse(newsData[index].newsDescription).outerHtml}',
          //         //   style: const TextStyle(
          //         //     fontFamily: 'Poppins',
          //         //     fontSize: 12,
          //         //     fontWeight: FontWeight.w600,
          //         //     color: kDarkGrey,
          //         //   ),
          //         // ),
          //         const SizedBox(
          //           height: 10,
          //         ),
          //         Row(
          //           mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //           children: const [
          //             Text(
          //               '06 Jun 2022 07:01 pm',
          //               style: TextStyle(
          //                 fontFamily: 'Poppins',
          //                 fontSize: 12,
          //                 fontWeight: FontWeight.w600,
          //                 color: kRedLight,
          //               ),
          //             ),
          //             Icon(
          //               Icons.keyboard_double_arrow_right,
          //               color: kRedLight,
          //               size: 18,
          //             )
          //           ],
          //         ),
          //       ],
          //     ),
          //   ),
          // ),
          GetBuilder<NewsViewModel>(
            builder: (controller) {
              if (controller.apiResponse.status == Status.COMPLETE) {
                print('news data');

                List<ns.NewsResponseModel> newsData =
                    controller.apiResponse.data;
                if (newsData.isEmpty) {
                  print('no dattatata');
                  return const Center(child: Text('No Data Found'));
                }

                return ListView.separated(
                  padding: EdgeInsets.zero,
                  separatorBuilder: (context, index) => const SizedBox(
                    height: 10,
                  ),
                  itemCount: newsData.length,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemBuilder: (context, index) => Container(
                    margin: EdgeInsets.symmetric(horizontal: Get.width * 0.03),
                    padding: EdgeInsets.all(Get.width * 0.03),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.3),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Html(data: '${newsData[index].title}'),
                        Text(
                          newsData[index].title!.rendered.toString(),
                          style: const TextStyle(
                            fontFamily: 'Poppins',
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: kDarkGrey,
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              '${newsData[index].modified}',
                              style: const TextStyle(
                                fontFamily: 'Poppins',
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: kRedLight,
                              ),
                            ),
                            GestureDetector(
                              onTap: () async {
                                String url = 'newsData[index].link';
                                print('url==${newsData[index].link}');
                                if (!await launchUrl(
                                    Uri.parse(newsData[index].link.toString())))
                                  throw 'Could not launch $url';
                              },
                              child: const Icon(
                                Icons.keyboard_double_arrow_right,
                                color: kRedLight,
                                size: 18,
                              ),
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              } else {
                if (controller.apiResponse.status == Status.ERROR) {
                  return Text('No Data Found');
                }
                return Text('No data');
              }
            },
          ),

          const SizedBox(height: 30),
          GetBuilder<NewProgramArrivalsEnhanceViewModel>(
            builder: (controller) {
              if (controller.apiResponse.status == Status.COMPLETE) {
                List<NewProgramArrivalsEnhanceResponseModel> data =
                    controller.apiResponse.data;
                return Container(
                  height: 500,
                  width: Get.width,
                  margin: EdgeInsets.symmetric(horizontal: Get.width * 0.03),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                          color: Colors.black.withOpacity(0.2), blurRadius: 10),
                    ],
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: GetBuilder<DashboardController>(
                    builder: (controller) => Column(
                      children: [
                        const SizedBox(height: 15),
                        const Text(
                          'New Program Arrivals',
                          style: TextStyle(
                            fontFamily: 'Poppins',
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: kGrey,
                          ),
                        ),
                        const SizedBox(height: 20),
                        SizedBox(
                          height: 385,
                          width: Get.width * 0.9,
                          child: PageView(
                            controller: _pageController,
                            onPageChanged: (int value) {
                              controller.setSelectedPage(value);
                            },
                            children: List.generate(
                              data.length,
                              (index) => Container(
                                height: 385,
                                width: Get.width * 0.9,
                                margin:
                                    const EdgeInsets.symmetric(horizontal: 10),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  border: Border.all(color: kBorderGrey),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    data[index].instImagePath == null
                                        ? Container(
                                            height: 110,
                                            width: Get.width * 0.9,
                                            decoration: const BoxDecoration(
                                                color: Colors.redAccent,
                                                borderRadius: BorderRadius.only(
                                                  topLeft: Radius.circular(10),
                                                  topRight: Radius.circular(10),
                                                ),
                                                image: DecorationImage(
                                                    fit: BoxFit.cover,
                                                    image: NetworkImage(
                                                        'https://cdn.britannica.com/85/13085-050-C2E88389/Corpus-Christi-College-University-of-Cambridge-England.jpg'))),
                                          )
                                        : Container(
                                            width: Get.width * 0.9,
                                            height: 110,
                                            decoration: BoxDecoration(
                                                color: Colors.redAccent,
                                                borderRadius:
                                                    const BorderRadius.only(
                                                  topLeft: Radius.circular(10),
                                                  topRight: Radius.circular(10),
                                                ),
                                                image: DecorationImage(
                                                    fit: BoxFit.cover,
                                                    image: NetworkImage(
                                                        '${'https://appmsmunifyprod.blob.core.windows.net/docs/files/institution/'}${data[index].instImagePath}'))),
                                          ),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 10),
                                      child: Text(
                                        '${data[index].programName}',
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          fontFamily: 'Poppins',
                                          fontSize: 16,
                                          height: 3,
                                          fontWeight: FontWeight.w600,
                                          color: kDarkBlue,
                                        ),
                                      ),
                                    ),
                                    const Divider(),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 10),
                                      child: Text(
                                        '${data[index].intakeName}',
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          fontFamily: 'Poppins',
                                          fontSize: 16,
                                          fontWeight: FontWeight.w400,
                                          color: kGrey,
                                        ),
                                      ),
                                    ),
                                    Padding(
                                      padding:
                                          EdgeInsets.symmetric(horizontal: 10),
                                      child: Text(
                                        '${data[index].durationTime}',
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          fontFamily: 'Poppins',
                                          fontSize: 16,
                                          fontWeight: FontWeight.w400,
                                          color: kGrey,
                                        ),
                                      ),
                                    ),
                                    const Divider(),
                                    const SizedBox(
                                      height: 7,
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 10),
                                      child: Row(
                                        children: [
                                          SvgPicture.asset(
                                              'assets/icons/Institution - Gray.svg'),
                                          const SizedBox(width: 10),
                                          SizedBox(
                                            width: Get.width * 0.65,
                                            child: Text(
                                              '${data[index].institutionName}',
                                              overflow: TextOverflow.ellipsis,
                                              maxLines: 2,
                                              style: const TextStyle(
                                                fontFamily: 'Poppins',
                                                fontSize: 12,
                                                fontWeight: FontWeight.w600,
                                                color: kGrey,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 15,
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 10),
                                      child: Row(
                                        children: [
                                          SvgPicture.asset(
                                              'assets/icons/Location - Gray.svg'),
                                          const SizedBox(
                                            width: 10,
                                          ),
                                          Text(
                                            '${data[index].countryName}',
                                            overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(
                                              fontFamily: 'Poppins',
                                              fontSize: 12,
                                              fontWeight: FontWeight.w600,
                                              color: kGrey,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const Spacer(),
                                    GestureDetector(
                                      onTap: () {
                                        Get.to(ProgramDetailScreen(
                                          programId: data[index].programId,
                                        ));
                                      },
                                      child: Container(
                                        height: 35,
                                        width: Get.width,
                                        decoration: const BoxDecoration(
                                            color: kRedLight,
                                            borderRadius: BorderRadius.only(
                                              bottomLeft: Radius.circular(10),
                                              bottomRight: Radius.circular(10),
                                            )),
                                        child: const Center(
                                          child: Text(
                                            'Explore More',
                                            style: TextStyle(
                                              fontFamily: 'Poppins',
                                              fontSize: 12,
                                              fontWeight: FontWeight.w600,
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            GestureDetector(
                              onTap: () {
                                _pageController.previousPage(
                                  duration: const Duration(seconds: 1),
                                  curve: Curves.ease,
                                );
                              },
                              child: Image.asset(
                                'assets/icons/backward_button.png',
                                height: 25,
                                width: 25,
                                color: controller.selectedPage == 0
                                    ? Colors.grey
                                    : kRedLight,
                              ),
                            ),
                            const SizedBox(width: 15),
                            GestureDetector(
                              onTap: () {
                                log('${_pageController.page}');
                                _pageController.nextPage(
                                  duration: const Duration(seconds: 1),
                                  curve: Curves.ease,
                                );
                                setState(() {});
                              },
                              child: Image.asset(
                                'assets/icons/forward_button.png',
                                height: 25,
                                width: 25,
                                color: controller.selectedPage ==
                                        newProgramArrivals.length - 1
                                    ? Colors.grey
                                    : kRedLight,
                              ),
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              } else {
                if (controller.apiResponse.status == Status.ERROR) {
                  return Text("No Data Found");
                }
                return const Center(child: CircularProgressIndicator());
              }
            },
          ),

          const SizedBox(
            height: 25,
          ),
          supportSection()
        ],
      ),
    );
  }
}
