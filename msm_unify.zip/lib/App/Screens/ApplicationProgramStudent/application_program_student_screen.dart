import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:msm_unify/App/Screens/AddStudent/add_student_screen.dart';
import 'package:msm_unify/App/Screens/ApplicationProgramStudent/widget/contact_info_tab_screen.dart';
import 'package:msm_unify/App/Screens/ApplicationProgramStudent/widget/test_scores_tab_screen.dart';
import 'package:msm_unify/App/common/color_constant.dart';
import 'package:msm_unify/model/responseModek/student_view_response_model.dart';

import 'widget/application_program_advisor_assigned_tab.dart';
import 'widget/application_program_education_info_tab.dart';
import 'widget/application_program_info_tab_screen.dart';
import 'widget/application_program_personal_info_tab.dart';

class ApplicationProgramStudentScreen extends StatefulWidget {
  final StudentViewResponseModel? data;

  const ApplicationProgramStudentScreen({super.key, this.data});

  @override
  _ApplicationProgramStudentScreenState createState() =>
      _ApplicationProgramStudentScreenState();
}

class _ApplicationProgramStudentScreenState
    extends State<ApplicationProgramStudentScreen>
    with SingleTickerProviderStateMixin {
  TabController? _tabController;
  String? _selectedCountry;
  String? _selectedPartner;
  final List<String> _country = [
    'Yemen',
    'India',
    "USA",
    "Afghanistan",
    "Argentina"
  ];
  final List<String> _partner = ['All', 'GMO', 'MSM Unify'];
  @override
  void initState() {
    _tabController = new TabController(length: 6, vsync: this);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: DefaultTabController(
        length: 6,
        child: Scaffold(
          body: Padding(
              padding: const EdgeInsets.all(10),
              child: NestedScrollView(
                headerSliverBuilder:
                    (BuildContext context, bool innerBoxIsScrolled) {
                  return <Widget>[
                    SliverToBoxAdapter(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                "Search program to apply",
                                style: TextStyle(
                                    color: Color(0xff555555),
                                    fontFamily: 'Roboto',
                                    fontSize: 11),
                              ),
                              const SizedBox(
                                height: 5,
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(
                                    height: Get.height * 0.060,
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      border: Border.all(color: kGrey4),
                                    ),
                                    child: DropdownButtonHideUnderline(
                                      child: DropdownButton(
                                          borderRadius:
                                              BorderRadius.circular(5),
                                          hint: const Text("Nationalities"),
                                          value: _selectedCountry,
                                          items: _country.map((country) {
                                            return DropdownMenuItem(
                                                value: country,
                                                child: Text(
                                                  country,
                                                  style: const TextStyle(
                                                      color: kGrey4,
                                                      fontFamily: "Roboto",
                                                      fontSize: 13),
                                                ));
                                          }).toList(),
                                          onChanged: (newValue) {
                                            setState(() {
                                              _selectedCountry =
                                                  newValue as String?;
                                            });
                                          }),
                                    ),
                                  ),
                                  Flexible(
                                    child: SizedBox(
                                      height: Get.height * 0.060,
                                      width: Get.width * 0.55,
                                      child: TextFormField(
                                        decoration: InputDecoration(
                                            hintStyle: TextStyle(
                                                color: Colors.black
                                                    .withOpacity(0.2)),
                                            hintText:
                                                'What do you Want to study?',
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            )),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  SizedBox(
                                    height: Get.height * 0.060,
                                    width: Get.width * 0.30,
                                    child: TextFormField(
                                      decoration: InputDecoration(
                                          hintStyle: TextStyle(
                                              color: Colors.black
                                                  .withOpacity(0.2)),
                                          hintText: 'Destination',
                                          border: OutlineInputBorder(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                          )),
                                    ),
                                  ),
                                  Container(
                                    height: Get.height * 0.060,
                                    width: Get.width * 0.35,
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      border: Border.all(color: kGrey4),
                                    ),
                                    child: DropdownButtonHideUnderline(
                                      child: DropdownButton(
                                          borderRadius:
                                              BorderRadius.circular(5),
                                          hint: const Text("All"),
                                          value: _selectedPartner,
                                          items: _partner.map((partner) {
                                            return DropdownMenuItem(
                                                value: partner,
                                                child: Text(
                                                  partner,
                                                  style: const TextStyle(
                                                      color: kGrey4,
                                                      fontFamily: "Roboto",
                                                      fontSize: 13),
                                                ));
                                          }).toList(),
                                          onChanged: (newValue) {
                                            setState(() {
                                              _selectedPartner =
                                                  newValue as String?;
                                            });
                                          }),
                                    ),
                                  ),
                                  Container(
                                    height: Get.height * 0.060,
                                    width: Get.width * 0.25,
                                    decoration: BoxDecoration(
                                        color: kNavy,
                                        borderRadius:
                                            BorderRadius.circular(10)),
                                    child: const Center(
                                      child: Text(
                                        "Search",
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 14,
                                          fontFamily: 'Roboto',
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  GestureDetector(
                                    onTap: () {
                                      Get.back();
                                    },
                                    child: SvgPicture.asset(
                                      'assets/icons/back.svg',
                                      height: 22,
                                      width: 22,
                                    ),
                                  ),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  const Text(
                                    'Back',
                                    style: TextStyle(
                                        color: kGrey5,
                                        fontFamily: 'Poppins',
                                        fontWeight: FontWeight.w500,
                                        fontSize: 16),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Application for \n ${widget.data!.genInfo!.firstName}',
                                style: const TextStyle(
                                    color: kNavy,
                                    fontSize: 20,
                                    fontFamily: 'Poppins'),
                              ),
                              Flexible(
                                child: GestureDetector(
                                  onTap: () {
                                    Get.to(AddStudentScreen());
                                  },
                                  child: Container(
                                    padding: EdgeInsets.all(8),
                                    height: Get.height * 0.05,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        color: Color(0xff565656)),
                                    child: const Center(
                                      child: Flexible(
                                        child: Text(
                                          'Apply With Another Student',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 11,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          const Text(
                            'Review of existing student data',
                            style: TextStyle(
                                color: Color(0xff565656), fontSize: 12),
                          )
                        ],
                      ),
                    ),
                    SliverToBoxAdapter(
                      child: TabBar(
                        controller: _tabController,
                        isScrollable: true,
                        unselectedLabelColor: Colors.black,
                        indicatorColor: Colors.red,
                        labelColor: Colors.red,
                        tabs: const [
                          Tab(
                            child: Text("Program Info"),
                          ),
                          Tab(
                            child: Text("Personal Info"),
                          ),
                          Tab(
                            child: Text("Contact Info"),
                          ),
                          Tab(
                            child: Text("Advisor Assigned"),
                          ),
                          Tab(
                            child: Text("Education Info"),
                          ),
                          Tab(
                            child: Text("Test Scorees"),
                          ),
                        ],
                      ),
                    ),
                  ];
                },
                body: TabBarView(
                  controller: _tabController,
                  children: [
                    const ProgramInfoTab(),
                    PersonalInfoTab(data: widget.data),
                    ContactInfoTabScreen(data: widget.data),
                    const AppAdvisorAssignTab(),
                    const AppEducationTab(),
                    const TestScoresTabScreen(),
                  ],
                ),
              )),
        ),
      ),
    );
  }
}
