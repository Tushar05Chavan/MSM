import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:msm_unify/App/common/AppConfig/support_section.dart';

import '../../../common/color_constant.dart';

class AppEducationTab extends StatefulWidget {
  const AppEducationTab({Key? key}) : super(key: key);

  @override
  State<AppEducationTab> createState() => _AppEducationTabState();
}

class _AppEducationTabState extends State<AppEducationTab> {
  final _gradeAvg = TextEditingController();
  final _institute = TextEditingController();
  final _city = TextEditingController();
  final _startDate = TextEditingController();
  final _endDate = TextEditingController();
  final _awdDate = TextEditingController();
  final _degree = TextEditingController();

  final DateFormat formatter = DateFormat('dd-MM-yyyy');

  String? _selectedCountry;
  List<String> _country = ['India', 'Laos', 'Latvia', 'Mali', 'Libya'];

  String? _selectedEducation;
  List<String> _education = [
    'Grade 10',
    'Grade 12',
    'BCA',
    'MCA',
    'B.Com',
    'M.Com'
  ];

  String? _selectedScheme;
  List<String> _scheme = ['Search', 'All', 'None'];

  String? _selectedProvince;
  List<String> _province = ['Search', 'All', 'None'];

  String? _selectedLanguage;
  List<String> _language = [
    'English',
    'Gujarati',
    'Hindi',
    'Nepali',
    'Marathi',
    'Oromo'
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Column(
              children: [
                Container(
                  height: Get.height * 0.070,
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: kGrey),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton(
                        borderRadius: BorderRadius.circular(10),
                        hint: const Text("Country of Education"),
                        value: _selectedCountry,
                        items: _country.map((country) {
                          return DropdownMenuItem(
                              value: country,
                              child: Text(
                                country,
                                style: const TextStyle(
                                    color: kGrey,
                                    fontFamily: "Roboto",
                                    fontSize: 13),
                              ));
                        }).toList(),
                        onChanged: (newValue) {
                          setState(() {
                            _selectedCountry = newValue as String?;
                          });
                        }),
                  ),
                ),
                SizedBox(
                  height: Get.height * 0.02,
                ),
                Container(
                  height: Get.height * 0.070,
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: kGrey),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton(
                        borderRadius: BorderRadius.circular(10),
                        hint: const Text("Highest Level of Education"),
                        value: _selectedEducation,
                        items: _education.map((education) {
                          return DropdownMenuItem(
                              value: education,
                              child: Text(
                                education,
                                style: const TextStyle(
                                    color: kGrey,
                                    fontFamily: "Roboto",
                                    fontSize: 13),
                              ));
                        }).toList(),
                        onChanged: (newValue) {
                          setState(() {
                            _selectedEducation = newValue as String?;
                          });
                        }),
                  ),
                ),
                SizedBox(
                  height: Get.height * 0.02,
                ),
                Container(
                  height: Get.height * 0.070,
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: kGrey),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton(
                        borderRadius: BorderRadius.circular(10),
                        hint: const Text("Grading Scheme"),
                        value: _selectedScheme,
                        items: _scheme.map((scheme) {
                          return DropdownMenuItem(
                              value: scheme,
                              child: Text(
                                scheme,
                                style: const TextStyle(
                                    color: kGrey,
                                    fontFamily: "Roboto",
                                    fontSize: 13),
                              ));
                        }).toList(),
                        onChanged: (newValue) {
                          setState(() {
                            _selectedScheme = newValue as String?;
                          });
                        }),
                  ),
                ),
                SizedBox(
                  height: Get.height * 0.02,
                ),
                TextFormField(
                  controller: _gradeAvg,
                  decoration: InputDecoration(
                    hintText: 'Grade Average',
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: const BorderSide(
                          color: kGrey,
                          width: 1,
                        )),
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: const BorderSide(
                          color: kGrey,
                          width: 1,
                        )),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: const BorderSide(
                          color: kGrey,
                          width: 2,
                        )),
                  ),
                ),
                SizedBox(
                  height: Get.height * 0.08,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    GestureDetector(
                      onTap: () {
                        showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return SimpleDialog(
                              shape: ContinuousRectangleBorder(
                                  borderRadius: BorderRadius.circular(15),
                                  side: BorderSide(color: kRed)),
                              children: [
                                StatefulBuilder(
                                  builder: (BuildContext context,
                                      void Function(void Function()) setState) {
                                    return Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 10),
                                      child: Column(
                                        children: [
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              const Text(
                                                'Add School Details',
                                                style: TextStyle(
                                                    color: kNavy,
                                                    fontFamily: 'Poppins',
                                                    fontSize: 18,
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                              Flexible(
                                                child: InkWell(
                                                  onTap: () {
                                                    Get.back();
                                                  },
                                                  child: Container(
                                                    height: Get.height * 0.03,
                                                    width: Get.width * 0.08,
                                                    decoration: BoxDecoration(
                                                        color: kRed,
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(5)),
                                                    child: const Icon(
                                                      Icons.close,
                                                      color: Colors.white,
                                                      size: 25,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          SizedBox(
                                            height: Get.height * 0.02,
                                          ),
                                          Container(
                                            height: Get.height * 0.070,
                                            width: double.infinity,
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 10),
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(15),
                                              border: Border.all(color: kGrey),
                                            ),
                                            child: DropdownButtonHideUnderline(
                                              child: DropdownButton(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  hint: const Text(
                                                      "Level of Education"),
                                                  value: _selectedEducation,
                                                  items: _education
                                                      .map((education) {
                                                    return DropdownMenuItem(
                                                        value: education,
                                                        child: Text(
                                                          education,
                                                          style:
                                                              const TextStyle(
                                                                  color: kGrey,
                                                                  fontFamily:
                                                                      "Roboto",
                                                                  fontSize: 13),
                                                        ));
                                                  }).toList(),
                                                  onChanged: (newValue) {
                                                    setState(() {
                                                      _selectedEducation =
                                                          newValue as String?;
                                                    });
                                                  }),
                                            ),
                                          ),
                                          SizedBox(
                                            height: Get.height * 0.02,
                                          ),
                                          Container(
                                            height: Get.height * 0.070,
                                            width: double.infinity,
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 10),
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(15),
                                              border: Border.all(color: kGrey),
                                            ),
                                            child: DropdownButtonHideUnderline(
                                              child: DropdownButton(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  hint: const Text(
                                                      "Country of Education"),
                                                  value: _selectedCountry,
                                                  items:
                                                      _country.map((country) {
                                                    return DropdownMenuItem(
                                                        value: country,
                                                        child: Text(
                                                          country,
                                                          style:
                                                              const TextStyle(
                                                                  color: kGrey,
                                                                  fontFamily:
                                                                      "Roboto",
                                                                  fontSize: 13),
                                                        ));
                                                  }).toList(),
                                                  onChanged: (newValue) {
                                                    setState(() {
                                                      _selectedCountry =
                                                          newValue as String?;
                                                    });
                                                  }),
                                            ),
                                          ),
                                          SizedBox(
                                            height: Get.height * 0.02,
                                          ),
                                          TextFormField(
                                            controller: _institute,
                                            decoration: InputDecoration(
                                              hintText: 'Name of Institution',
                                              border: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                  borderSide: const BorderSide(
                                                    color: kGrey,
                                                    width: 1,
                                                  )),
                                              enabledBorder: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                  borderSide: const BorderSide(
                                                    color: kGrey,
                                                    width: 1,
                                                  )),
                                              focusedBorder: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                  borderSide: const BorderSide(
                                                    color: kGrey,
                                                    width: 2,
                                                  )),
                                            ),
                                          ),
                                          SizedBox(
                                            height: Get.height * 0.02,
                                          ),
                                          Container(
                                            height: Get.height * 0.070,
                                            width: double.infinity,
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 10),
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(15),
                                              border: Border.all(color: kGrey),
                                            ),
                                            child: DropdownButtonHideUnderline(
                                              child: DropdownButton(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  hint: const Text("Province"),
                                                  value: _selectedProvince,
                                                  items:
                                                      _province.map((province) {
                                                    return DropdownMenuItem(
                                                        value: province,
                                                        child: Text(
                                                          province,
                                                          style:
                                                              const TextStyle(
                                                                  color: kGrey,
                                                                  fontFamily:
                                                                      "Roboto",
                                                                  fontSize: 13),
                                                        ));
                                                  }).toList(),
                                                  onChanged: (newValue) {
                                                    setState(() {
                                                      _selectedProvince =
                                                          newValue as String?;
                                                    });
                                                  }),
                                            ),
                                          ),
                                          SizedBox(
                                            height: Get.height * 0.02,
                                          ),
                                          TextFormField(
                                            controller: _city,
                                            decoration: InputDecoration(
                                              hintText: 'City/Town',
                                              border: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                  borderSide: const BorderSide(
                                                    color: kGrey,
                                                    width: 1,
                                                  )),
                                              enabledBorder: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                  borderSide: const BorderSide(
                                                    color: kGrey,
                                                    width: 1,
                                                  )),
                                              focusedBorder: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                  borderSide: const BorderSide(
                                                    color: kGrey,
                                                    width: 2,
                                                  )),
                                            ),
                                          ),
                                          SizedBox(
                                            height: Get.height * 0.02,
                                          ),
                                          Container(
                                            height: Get.height * 0.070,
                                            width: double.infinity,
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 10),
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(15),
                                              border: Border.all(color: kGrey),
                                            ),
                                            child: DropdownButtonHideUnderline(
                                              child: DropdownButton(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  hint: const Text(
                                                      "Primary Language of Instruction"),
                                                  value: _selectedLanguage,
                                                  items:
                                                      _language.map((language) {
                                                    return DropdownMenuItem(
                                                        value: language,
                                                        child: Text(
                                                          language,
                                                          style:
                                                              const TextStyle(
                                                                  color: kGrey,
                                                                  fontFamily:
                                                                      "Roboto",
                                                                  fontSize: 13),
                                                        ));
                                                  }).toList(),
                                                  onChanged: (newValue) {
                                                    setState(() {
                                                      _selectedLanguage =
                                                          newValue as String?;
                                                    });
                                                  }),
                                            ),
                                          ),
                                          SizedBox(
                                            height: Get.height * 0.02,
                                          ),
                                          TextFormField(
                                            controller: _startDate,
                                            cursorColor: kRed,
                                            decoration: InputDecoration(
                                              suffixIcon: IconButton(
                                                icon: Icon(Icons.today,
                                                    color: kGrey),
                                                onPressed: () async {
                                                  DateTime date =
                                                      DateTime(1900);
                                                  FocusScope.of(context)
                                                      .requestFocus(
                                                          FocusNode());

                                                  date = (await showDatePicker(
                                                      context: context,
                                                      initialDate:
                                                          DateTime.now(),
                                                      firstDate: DateTime(1900),
                                                      lastDate:
                                                          DateTime.now()))!;
                                                  _startDate.text =
                                                      formatter.format(date);
                                                },
                                              ),
                                              hintText: 'Start date DD/MM/YYYY',
                                              hintStyle: const TextStyle(
                                                  color: kGrey,
                                                  fontFamily: 'Roboto'),
                                              border: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                  borderSide: const BorderSide(
                                                    color: kGrey,
                                                    width: 1,
                                                  )),
                                              enabledBorder: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                  borderSide: const BorderSide(
                                                    color: kGrey,
                                                    width: 1,
                                                  )),
                                              focusedBorder: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                  borderSide: const BorderSide(
                                                    color: kGrey,
                                                    width: 2,
                                                  )),
                                            ),
                                          ),
                                          SizedBox(
                                            height: Get.height * 0.02,
                                          ),
                                          TextFormField(
                                            controller: _endDate,
                                            cursorColor: kRed,
                                            decoration: InputDecoration(
                                              suffixIcon: IconButton(
                                                icon: Icon(Icons.today,
                                                    color: kGrey),
                                                onPressed: () async {
                                                  DateTime date =
                                                      DateTime(1900);
                                                  FocusScope.of(context)
                                                      .requestFocus(
                                                          FocusNode());

                                                  date = (await showDatePicker(
                                                      context: context,
                                                      initialDate:
                                                          DateTime.now(),
                                                      firstDate: DateTime(1900),
                                                      lastDate:
                                                          DateTime.now()))!;
                                                  _endDate.text =
                                                      formatter.format(date);
                                                },
                                              ),
                                              hintText: 'End date DD/MM/YYYY',
                                              hintStyle: const TextStyle(
                                                  color: kGrey,
                                                  fontFamily: 'Roboto'),
                                              border: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                  borderSide: const BorderSide(
                                                    color: kGrey,
                                                    width: 1,
                                                  )),
                                              enabledBorder: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                  borderSide: const BorderSide(
                                                    color: kGrey,
                                                    width: 1,
                                                  )),
                                              focusedBorder: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                  borderSide: const BorderSide(
                                                    color: kGrey,
                                                    width: 2,
                                                  )),
                                            ),
                                          ),
                                          SizedBox(
                                            height: Get.height * 0.02,
                                          ),
                                          TextFormField(
                                            controller: _awdDate,
                                            cursorColor: kRed,
                                            decoration: InputDecoration(
                                              suffixIcon: IconButton(
                                                icon: Icon(Icons.today,
                                                    color: kGrey),
                                                onPressed: () async {
                                                  DateTime date =
                                                      DateTime(1900);
                                                  FocusScope.of(context)
                                                      .requestFocus(
                                                          FocusNode());

                                                  date = (await showDatePicker(
                                                      context: context,
                                                      initialDate:
                                                          DateTime.now(),
                                                      firstDate: DateTime(1900),
                                                      lastDate:
                                                          DateTime.now()))!;
                                                  _awdDate.text =
                                                      formatter.format(date);
                                                },
                                              ),
                                              hintText:
                                                  'Degree awarded date DD/MM/YYYY',
                                              hintStyle: const TextStyle(
                                                  color: kGrey,
                                                  fontFamily: 'Roboto'),
                                              border: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                  borderSide: const BorderSide(
                                                    color: kGrey,
                                                    width: 1,
                                                  )),
                                              enabledBorder: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                  borderSide: const BorderSide(
                                                    color: kGrey,
                                                    width: 1,
                                                  )),
                                              focusedBorder: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                  borderSide: const BorderSide(
                                                    color: kGrey,
                                                    width: 2,
                                                  )),
                                            ),
                                          ),
                                          SizedBox(
                                            height: Get.height * 0.02,
                                          ),
                                          TextFormField(
                                            controller: _degree,
                                            decoration: InputDecoration(
                                              hintText:
                                                  'Degree Awarded/Program Name',
                                              border: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                  borderSide: const BorderSide(
                                                    color: kGrey,
                                                    width: 1,
                                                  )),
                                              enabledBorder: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                  borderSide: const BorderSide(
                                                    color: kGrey,
                                                    width: 1,
                                                  )),
                                              focusedBorder: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                  borderSide: const BorderSide(
                                                    color: kGrey,
                                                    width: 2,
                                                  )),
                                            ),
                                          ),
                                          SizedBox(
                                            height: Get.height * 0.05,
                                          ),
                                          InkWell(
                                            onTap: () {
                                              showDialog(
                                                context: context,
                                                builder:
                                                    (BuildContext context) {
                                                  return SimpleDialog(
                                                    shape:
                                                        ContinuousRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        15),
                                                            side: BorderSide(
                                                                color: kRed)),
                                                    children: [
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .symmetric(
                                                                horizontal: 10),
                                                        child: Column(
                                                          children: [
                                                            Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .end,
                                                              children: [
                                                                InkWell(
                                                                  onTap: () {
                                                                    Get.back();
                                                                  },
                                                                  child:
                                                                      Container(
                                                                    height:
                                                                        Get.height *
                                                                            0.03,
                                                                    width:
                                                                        Get.width *
                                                                            0.06,
                                                                    decoration: BoxDecoration(
                                                                        color:
                                                                            kRed,
                                                                        borderRadius:
                                                                            BorderRadius.circular(5)),
                                                                    child: Icon(
                                                                      Icons
                                                                          .close,
                                                                      color: Colors
                                                                          .white,
                                                                      size: 15,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                            SvgPicture.asset(
                                                                'assets/icons/Cross_ Payment failed.svg'),
                                                            SizedBox(
                                                              height:
                                                                  Get.height *
                                                                      0.01,
                                                            ),
                                                            const Text(
                                                              'Fill Mandatory Fields',
                                                              style: TextStyle(
                                                                  color: kRed,
                                                                  fontFamily:
                                                                      'Roboto',
                                                                  fontSize: 25),
                                                            ),
                                                            SizedBox(
                                                              height:
                                                                  Get.height *
                                                                      0.10,
                                                            ),
                                                            Container(
                                                              height:
                                                                  Get.height *
                                                                      0.045,
                                                              width: Get.width *
                                                                  0.25,
                                                              decoration: BoxDecoration(
                                                                  border: Border
                                                                      .all(
                                                                          color:
                                                                              kRed),
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              10)),
                                                              child: const Center(
                                                                  child: Text(
                                                                      'Retry',
                                                                      style: TextStyle(
                                                                          color:
                                                                              kRed,
                                                                          fontFamily:
                                                                              'Roboto'))),
                                                            ),
                                                          ],
                                                        ),
                                                      )
                                                    ],
                                                  );
                                                },
                                              );
                                            },
                                            child: Container(
                                              height: Get.height * 0.04,
                                              width: Get.width * 0.20,
                                              decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  color: kRed),
                                              child: Center(
                                                child: Text('Add',
                                                    style: TextStyle(
                                                        fontFamily: 'Roboto',
                                                        color: Colors.white)),
                                              ),
                                            ),
                                          )
                                        ],
                                      ),
                                    );
                                  },
                                )
                              ],
                            );
                          },
                        );
                      },
                      child: Container(
                          width: Get.width * 0.40,
                          height: Get.height * 0.04,
                          decoration: BoxDecoration(
                            color: Color(0xff565656),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            children: [
                              Icon(Icons.add, color: Colors.white),
                              Text(
                                'Add More Education',
                                style: TextStyle(
                                    fontSize: 13,
                                    fontFamily: 'Roboto',
                                    color: Colors.white),
                              )
                            ],
                          )),
                    ),
                  ],
                ),
                SizedBox(
                  height: Get.height * 0.05,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    GestureDetector(
                      onTap: () {
                        Get.back();
                      },
                      child: Row(
                        children: [
                          SvgPicture.asset(
                            'assets/icons/back.svg',
                            height: 22,
                            width: 22,
                          ),
                          const SizedBox(
                            width: 10,
                          ),
                          const Text(
                            'Back',
                            style: TextStyle(
                                color: kGrey5,
                                fontFamily: 'Poppins',
                                fontWeight: FontWeight.w500,
                                fontSize: 16),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: Get.width * 0.05,
                    ),
                    GestureDetector(
                      onTap: () {
                        showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return SimpleDialog(
                              shape: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide(color: kRed)),
                              children: [
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10),
                                  child: Column(
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          InkWell(
                                            onTap: () {
                                              Get.back();
                                            },
                                            child: Container(
                                              height: Get.height * 0.03,
                                              width: Get.width * 0.06,
                                              decoration: BoxDecoration(
                                                  color: kRed,
                                                  borderRadius:
                                                      BorderRadius.circular(5)),
                                              child: Icon(
                                                Icons.close,
                                                color: Colors.white,
                                                size: 15,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      SvgPicture.asset(
                                          'assets/icons/Cross_ Payment failed.svg'),
                                      SizedBox(
                                        height: Get.height * 0.01,
                                      ),
                                      const Text(
                                        'Fill Mandatory Fields',
                                        style: TextStyle(
                                            color: kRed,
                                            fontFamily: 'Roboto',
                                            fontSize: 25),
                                      ),
                                      SizedBox(
                                        height: Get.height * 0.10,
                                      ),
                                      Container(
                                        height: Get.height * 0.045,
                                        width: Get.width * 0.25,
                                        decoration: BoxDecoration(
                                            border: Border.all(color: kRed),
                                            borderRadius:
                                                BorderRadius.circular(10)),
                                        child: const Center(
                                            child: Text('Retry',
                                                style: TextStyle(
                                                    color: kRed,
                                                    fontFamily: 'Roboto'))),
                                      ),
                                    ],
                                  ),
                                )
                              ],
                            );
                          },
                        );
                      },
                      child: Container(
                        width: Get.width * 0.40,
                        height: Get.height * 0.04,
                        decoration: BoxDecoration(
                          color: Colors.green,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Center(
                            child: Text(
                          'Save & Continue',
                          style: TextStyle(
                              fontFamily: 'Roboto', color: Colors.white),
                        )),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: Get.height * 0.30,
                ),
                supportSection()
              ],
            ),
          ),
        ),
      ),
    );
  }
}
