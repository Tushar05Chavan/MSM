import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:msm_unify/Api/api_response.dart';
import 'package:msm_unify/App/Screens/StudentEdit/widget/student_edit_documents_tab.dart';
import 'package:msm_unify/App/common/AppConfig/common_textfiled.dart';
import 'package:msm_unify/App/common/AppConfig/support_section.dart';
import 'package:msm_unify/App/common/color_constant.dart';
import 'package:msm_unify/viewModel/student_view_view_model.dart';

import '../../../model/responseModek/student_view_response_model.dart';
import 'widget/student_application_tab.dart';
import 'widget/student_education_tab.dart';
import 'widget/student_intrest_tab.dart';
import 'widget/student_note_tab.dart';
import 'widget/student_test_scrores_tab.dart';
import 'widget/student_visa_tab.dart';

class StudentEditScreen extends StatefulWidget {
  final int? studentId;

  const StudentEditScreen({Key? key, this.studentId}) : super(key: key);

  @override
  _StudentEditScreenState createState() => _StudentEditScreenState();
}

class _StudentEditScreenState extends State<StudentEditScreen>
    with SingleTickerProviderStateMixin {
  String? _selectedCountry;
  String? _selectedPartner;
  final List<String> _country = [
    'Yemen',
    'India',
    "USA",
    "Afghanistan",
    "Argentina"
  ];
  String? selectedTitle;
  String? selectedState;
  String? selectedState1;
  String? selectedCountry1;
  String? selectedCountry2;
  String? selectedFirstLanguage;
  String? selectedCountryCode;
  String? selectedCountryOfCitizenship;
  final List<String> _title = ['Mr.', 'Ms.', 'Miss', 'Mrs.'];
  final List<String> _country1 = ['india', 'japan', 'china', 'pakistan'];
  final List<String> _country2 = ['india', 'japan', 'china', 'pakistan'];
  final List<String> _state = ['Gujarat', 'MP', 'UP', 'CSK'];
  final List<String> _state1 = ['Gujarat', 'MP', 'UP', 'CSK'];
  final List<String> _countryOfCitizenship = ['Mr.', 'Ms.', 'Miss', 'Mrs.'];

  final List<String> _countryCode = [
    '91(india)',
    '371(Latvia)',
  ];
  final List<String> _fistLanguage = ['Hindi', 'Gujarati', 'English', 'Tamil'];
  TabController? _tabController;
  final List<String> _partner = ['All', 'GMO', 'MSM Unify'];
  final PageController _controller = PageController(
    initialPage: 0,
  );
  String? indexed = '0';

  _onPageViewChange(int page) {
    // print("Current Page: " + page.toString());
    indexed = page.toString();
    setState(() {});
    print('index===$indexed');
  }

  final StudentViewViewModel _studentViewViewModel =
      Get.put(StudentViewViewModel());

  StudentViewResponseModel? response;
  Future<void> studentData() async {
    print("ID of STUDENT=====${widget.studentId}");
    await _studentViewViewModel.studentViewViewModel(
        studentId: widget.studentId);
  }

  @override
  void initState() {
    studentData();
    _tabController = TabController(length: 7, vsync: this);
    super.initState();
  }

  final DateFormat formatter = DateFormat('dd-MM-yyyy');
  final TextEditingController _date = TextEditingController();
  bool edit = false;
  bool _checkboxListTile = false;
  bool emergency = false;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: DefaultTabController(
        length: 7,
        child: Scaffold(
          body: Padding(
            padding: const EdgeInsets.all(10),
            child: GetBuilder<StudentViewViewModel>(
              builder: (controller) {
                if (controller.apiResponse.status == Status.COMPLETE) {
                  StudentViewResponseModel resp = controller.apiResponse.data;
                  print("STUDENT VIEW RESPONSE DATA === $resp");
                  return NestedScrollView(
                    headerSliverBuilder:
                        (BuildContext context, bool innerBoxIsScrolled) {
                      return <Widget>[
                        SliverToBoxAdapter(
                          child: Column(
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    "Search program to apply",
                                    style: TextStyle(
                                        color: Color(0xff555555),
                                        fontFamily: 'Roboto',
                                        fontSize: 11),
                                  ),
                                  const SizedBox(
                                    height: 5,
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Container(
                                        height: Get.height * 0.060,
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 10),
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          border: Border.all(color: kGrey4),
                                        ),
                                        child: DropdownButtonHideUnderline(
                                          child: DropdownButton(
                                              borderRadius:
                                                  BorderRadius.circular(5),
                                              hint: const Text("Nationalities"),
                                              value: _selectedCountry,
                                              items: _country.map((country) {
                                                return DropdownMenuItem(
                                                    value: country,
                                                    child: Text(
                                                      country,
                                                      style: const TextStyle(
                                                          color: kGrey4,
                                                          fontFamily: "Roboto",
                                                          fontSize: 13),
                                                    ));
                                              }).toList(),
                                              onChanged: (newValue) {
                                                setState(() {
                                                  _selectedCountry =
                                                      newValue as String?;
                                                });
                                              }),
                                        ),
                                      ),
                                      Flexible(
                                        child: SizedBox(
                                          height: Get.height * 0.060,
                                          width: Get.width * 0.55,
                                          child: TextFormField(
                                            decoration: InputDecoration(
                                                hintStyle: TextStyle(
                                                    color: Colors.black
                                                        .withOpacity(0.2)),
                                                hintText:
                                                    'What do you Want to study?',
                                                border: OutlineInputBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                )),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      SizedBox(
                                        height: Get.height * 0.060,
                                        width: Get.width * 0.30,
                                        child: TextFormField(
                                          decoration: InputDecoration(
                                              hintStyle: TextStyle(
                                                  color: Colors.black
                                                      .withOpacity(0.2)),
                                              hintText: 'Destination',
                                              border: OutlineInputBorder(
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                              )),
                                        ),
                                      ),
                                      Container(
                                        height: Get.height * 0.060,
                                        width: Get.width * 0.35,
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 10),
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          border: Border.all(color: kGrey4),
                                        ),
                                        child: DropdownButtonHideUnderline(
                                          child: DropdownButton(
                                              borderRadius:
                                                  BorderRadius.circular(5),
                                              hint: const Text("All"),
                                              value: _selectedPartner,
                                              items: _partner.map((partner) {
                                                return DropdownMenuItem(
                                                    value: partner,
                                                    child: Text(
                                                      partner,
                                                      style: const TextStyle(
                                                          color: kGrey4,
                                                          fontFamily: "Roboto",
                                                          fontSize: 13),
                                                    ));
                                              }).toList(),
                                              onChanged: (newValue) {
                                                setState(() {
                                                  _selectedPartner =
                                                      newValue as String?;
                                                });
                                              }),
                                        ),
                                      ),
                                      Container(
                                        height: Get.height * 0.060,
                                        width: Get.width * 0.25,
                                        decoration: BoxDecoration(
                                            color: kNavy,
                                            borderRadius:
                                                BorderRadius.circular(10)),
                                        child: const Center(
                                          child: Text(
                                            "Search",
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 14,
                                              fontFamily: 'Roboto',
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              const SizedBox(
                                height: 20,
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    children: [
                                      GestureDetector(
                                        onTap: () {
                                          Get.back();
                                        },
                                        child: SvgPicture.asset(
                                          'assets/icons/back.svg',
                                          height: 22,
                                          width: 22,
                                        ),
                                      ),
                                      const SizedBox(
                                        width: 10,
                                      ),
                                      const Text(
                                        'Back',
                                        style: TextStyle(
                                            color: kGrey5,
                                            fontFamily: 'Poppins',
                                            fontWeight: FontWeight.w500,
                                            fontSize: 16),
                                      ),
                                    ],
                                  ),
                                  GestureDetector(
                                    onTap: () {
                                      edit = false;
                                      showDialog(
                                          context: context,
                                          builder: (BuildContext context) {
                                            return StatefulBuilder(
                                              builder: (BuildContext context,
                                                  void Function(void Function())
                                                      setState) {
                                                return SimpleDialog(
                                                  shape: RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              15),
                                                      side: const BorderSide(
                                                          color:
                                                              kColorPrimary)),
                                                  children: [
                                                    Padding(
                                                      padding:
                                                          const EdgeInsets.all(
                                                              10),
                                                      child: edit == false
                                                          ? Container(
                                                              width: Get.width,
                                                              child:
                                                                  SingleChildScrollView(
                                                                child: Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Row(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .spaceBetween,
                                                                      children: [
                                                                        const Flexible(
                                                                          child:
                                                                              Text(
                                                                            'Personal Information (As indicated on your passport)',
                                                                            style:
                                                                                TextStyle(
                                                                              color: kRed,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Flexible(
                                                                          child:
                                                                              Container(
                                                                            height:
                                                                                Get.height * 0.04,
                                                                            width:
                                                                                Get.width * 0.08,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              color: kRed,
                                                                              borderRadius: BorderRadius.circular(8),
                                                                            ),
                                                                            child:
                                                                                const Icon(
                                                                              Icons.close,
                                                                              color: Colors.white,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                    const SizedBox(
                                                                      height:
                                                                          10,
                                                                    ),
                                                                    DropdownButtonHideUnderline(
                                                                      child: DropdownButtonFormField(
                                                                          decoration: InputDecoration(
                                                                            labelText:
                                                                                'Title *',
                                                                            border:
                                                                                OutlineInputBorder(
                                                                              borderRadius: BorderRadius.circular(15),
                                                                            ),
                                                                          ),
                                                                          borderRadius: BorderRadius.circular(5),
                                                                          hint: const Text("Mr."),
                                                                          value: selectedTitle,
                                                                          items: _title.map((tile) {
                                                                            return DropdownMenuItem(
                                                                                value: tile,
                                                                                child: Text(
                                                                                  tile,
                                                                                  style: const TextStyle(color: kGrey4, fontFamily: "Roboto", fontSize: 13),
                                                                                ));
                                                                          }).toList(),
                                                                          onChanged: (newValue) {
                                                                            setState(() {
                                                                              selectedTitle = newValue as String?;
                                                                            });
                                                                          }),
                                                                    ),
                                                                    const SizedBox(
                                                                      height:
                                                                          10,
                                                                    ),
                                                                    commontextfiled(
                                                                        labelText:
                                                                            Text(
                                                                          'First Name',
                                                                          style:
                                                                              TextStyle(
                                                                            color:
                                                                                Colors.black.withOpacity(0.2),
                                                                          ),
                                                                        ),
                                                                        hintText:
                                                                            'Krishna'),
                                                                    const SizedBox(
                                                                      height:
                                                                          20,
                                                                    ),
                                                                    commontextfiled(
                                                                        hintText:
                                                                            'Middle Name'),
                                                                    const SizedBox(
                                                                      height:
                                                                          20,
                                                                    ),
                                                                    commontextfiled(
                                                                        labelText:
                                                                            Text(
                                                                          'Last Name *',
                                                                          style:
                                                                              TextStyle(
                                                                            color:
                                                                                Colors.black.withOpacity(0.2),
                                                                          ),
                                                                        ),
                                                                        hintText:
                                                                            'Krishna'),
                                                                    const SizedBox(
                                                                      height:
                                                                          20,
                                                                    ),
                                                                    commontextfiled(
                                                                        labelText:
                                                                            Text(
                                                                          'Gender *',
                                                                          style:
                                                                              TextStyle(
                                                                            color:
                                                                                Colors.black.withOpacity(0.2),
                                                                          ),
                                                                        ),
                                                                        hintText:
                                                                            'Krishna'),
                                                                    const SizedBox(
                                                                      height:
                                                                          20,
                                                                    ),
                                                                    commontextfiled(
                                                                        labelText:
                                                                            Text(
                                                                          'Marital Status',
                                                                          style:
                                                                              TextStyle(
                                                                            color:
                                                                                Colors.black.withOpacity(0.2),
                                                                          ),
                                                                        ),
                                                                        hintText:
                                                                            'Krishna'),
                                                                    const SizedBox(
                                                                      height:
                                                                          20,
                                                                    ),
                                                                    TextFormField(
                                                                      controller:
                                                                          _date,
                                                                      cursorColor:
                                                                          kRed,
                                                                      decoration: InputDecoration(
                                                                          suffixIcon: IconButton(
                                                                            icon:
                                                                                const Icon(Icons.today),
                                                                            onPressed:
                                                                                () async {
                                                                              DateTime date = DateTime(1900);
                                                                              FocusScope.of(context).requestFocus(FocusNode());

                                                                              date = (await showDatePicker(context: context, initialDate: DateTime.now(), firstDate: DateTime(1900), lastDate: DateTime.now()))!;
                                                                              _date.text = formatter.format(date);
                                                                            },
                                                                          ),
                                                                          focusedBorder: OutlineInputBorder(
                                                                              borderRadius: BorderRadius.circular(15),
                                                                              borderSide: const BorderSide(
                                                                                color: Colors.black,
                                                                              )),
                                                                          hintStyle: TextStyle(color: Colors.black.withOpacity(0.2), fontFamily: 'Roboto'),
                                                                          hintText: '02/08/1997',
                                                                          border: OutlineInputBorder(
                                                                            borderRadius:
                                                                                BorderRadius.circular(15),
                                                                          )),
                                                                    ),
                                                                    const SizedBox(
                                                                      height: 5,
                                                                    ),
                                                                    const Text(
                                                                      'DD/MM/YYYY',
                                                                      style:
                                                                          TextStyle(
                                                                        color: Color(
                                                                            0xff808080),
                                                                        fontSize:
                                                                            11,
                                                                        fontFamily:
                                                                            'Roboto',
                                                                      ),
                                                                    ),
                                                                    const SizedBox(
                                                                      height:
                                                                          20,
                                                                    ),
                                                                    DropdownButtonHideUnderline(
                                                                      child: DropdownButtonFormField(
                                                                          decoration: InputDecoration(
                                                                            labelText:
                                                                                'First Language *',
                                                                            border:
                                                                                OutlineInputBorder(
                                                                              borderRadius: BorderRadius.circular(15),
                                                                            ),
                                                                          ),
                                                                          borderRadius: BorderRadius.circular(5),
                                                                          hint: const Text("Hindi"),
                                                                          value: selectedFirstLanguage,
                                                                          items: _fistLanguage.map((firstLanguage) {
                                                                            return DropdownMenuItem(
                                                                                value: firstLanguage,
                                                                                child: Text(
                                                                                  firstLanguage,
                                                                                  style: const TextStyle(color: kGrey4, fontFamily: "Roboto", fontSize: 13),
                                                                                ));
                                                                          }).toList(),
                                                                          onChanged: (newValue) {
                                                                            setState(() {
                                                                              selectedFirstLanguage = newValue as String?;
                                                                            });
                                                                          }),
                                                                    ),
                                                                    const SizedBox(
                                                                      height:
                                                                          20,
                                                                    ),
                                                                    commontextfiled(
                                                                        labelText:
                                                                            Text(
                                                                          'Contact Email ID *',
                                                                          style:
                                                                              TextStyle(
                                                                            color:
                                                                                Colors.black.withOpacity(0.2),
                                                                          ),
                                                                        ),
                                                                        hintText:
                                                                            'Krishna@gmail.com'),
                                                                    const SizedBox(
                                                                      height:
                                                                          20,
                                                                    ),
                                                                    DropdownButtonHideUnderline(
                                                                      child: DropdownButtonFormField(
                                                                          decoration: InputDecoration(
                                                                            labelText:
                                                                                'Country Code *',
                                                                            border:
                                                                                OutlineInputBorder(
                                                                              borderRadius: BorderRadius.circular(15),
                                                                            ),
                                                                          ),
                                                                          borderRadius: BorderRadius.circular(5),
                                                                          hint: const Text("91(India)"),
                                                                          value: selectedCountryCode,
                                                                          items: _countryCode.map((countryCode) {
                                                                            return DropdownMenuItem(
                                                                                value: countryCode,
                                                                                child: Text(
                                                                                  countryCode,
                                                                                  style: const TextStyle(color: kGrey4, fontFamily: "Roboto", fontSize: 13),
                                                                                ));
                                                                          }).toList(),
                                                                          onChanged: (newValue) {
                                                                            setState(() {
                                                                              selectedCountryCode = newValue as String?;
                                                                            });
                                                                          }),
                                                                    ),
                                                                    const SizedBox(
                                                                      height:
                                                                          20,
                                                                    ),
                                                                    commontextfiled(
                                                                        labelText:
                                                                            Text(
                                                                          'Contact Number',
                                                                          style:
                                                                              TextStyle(
                                                                            color:
                                                                                Colors.black.withOpacity(0.2),
                                                                          ),
                                                                        ),
                                                                        hintText:
                                                                            '83154878252'),
                                                                    const SizedBox(
                                                                      height:
                                                                          25,
                                                                    ),
                                                                    const Text(
                                                                      'Passport Details',
                                                                      style:
                                                                          TextStyle(
                                                                        color:
                                                                            kNavy,
                                                                        fontSize:
                                                                            14,
                                                                        fontFamily:
                                                                            'Poppins',
                                                                      ),
                                                                    ),
                                                                    const SizedBox(
                                                                      height:
                                                                          25,
                                                                    ),
                                                                    DropdownButtonHideUnderline(
                                                                      child: DropdownButtonFormField(
                                                                          decoration: InputDecoration(
                                                                            labelText:
                                                                                'Country of Citizenship *',
                                                                            border:
                                                                                OutlineInputBorder(
                                                                              borderRadius: BorderRadius.circular(15),
                                                                            ),
                                                                          ),
                                                                          borderRadius: BorderRadius.circular(5),
                                                                          hint: const Text("India"),
                                                                          value: selectedCountryOfCitizenship,
                                                                          items: _countryOfCitizenship.map((countryOfCitizenship) {
                                                                            return DropdownMenuItem(
                                                                                value: countryOfCitizenship,
                                                                                child: Text(
                                                                                  countryOfCitizenship,
                                                                                  style: const TextStyle(color: kGrey4, fontFamily: "Roboto", fontSize: 13),
                                                                                ));
                                                                          }).toList(),
                                                                          onChanged: (newValue) {
                                                                            setState(() {
                                                                              selectedCountryOfCitizenship = newValue as String?;
                                                                            });
                                                                          }),
                                                                    ),
                                                                    const SizedBox(
                                                                      height:
                                                                          25,
                                                                    ),
                                                                    commontextfiled(
                                                                        labelText:
                                                                            Text(
                                                                          'Passport Number *',
                                                                          style:
                                                                              TextStyle(
                                                                            color:
                                                                                Colors.black.withOpacity(0.2),
                                                                          ),
                                                                        ),
                                                                        hintText:
                                                                            '83154878252'),
                                                                    const SizedBox(
                                                                      height: 5,
                                                                    ),
                                                                    const Text(
                                                                      'Please write Passport number/Passport applied/Passport not available ',
                                                                      style: TextStyle(
                                                                          color: Color(
                                                                              0xff808080),
                                                                          fontFamily:
                                                                              'Roboto',
                                                                          fontSize:
                                                                              11),
                                                                    ),
                                                                    const SizedBox(
                                                                      height:
                                                                          15,
                                                                    ),
                                                                    TextFormField(
                                                                      controller:
                                                                          _date,
                                                                      cursorColor:
                                                                          kRed,
                                                                      decoration: InputDecoration(
                                                                          suffixIcon: IconButton(
                                                                            icon:
                                                                                const Icon(Icons.today),
                                                                            onPressed:
                                                                                () async {
                                                                              DateTime date = DateTime(1900);
                                                                              FocusScope.of(context).requestFocus(FocusNode());

                                                                              date = (await showDatePicker(context: context, initialDate: DateTime.now(), firstDate: DateTime(1900), lastDate: DateTime.now()))!;
                                                                              _date.text = formatter.format(date);
                                                                            },
                                                                          ),
                                                                          focusedBorder: OutlineInputBorder(
                                                                              borderRadius: BorderRadius.circular(15),
                                                                              borderSide: const BorderSide(
                                                                                color: Colors.black,
                                                                              )),
                                                                          hintStyle: TextStyle(color: Colors.black.withOpacity(0.2), fontFamily: 'Roboto'),
                                                                          hintText: '16/11/2022',
                                                                          border: OutlineInputBorder(
                                                                            borderRadius:
                                                                                BorderRadius.circular(15),
                                                                          )),
                                                                    ),
                                                                    const SizedBox(
                                                                      height: 5,
                                                                    ),
                                                                    const Text(
                                                                      'DD/MM/YYYY',
                                                                      style:
                                                                          TextStyle(
                                                                        color: Color(
                                                                            0xff808080),
                                                                        fontSize:
                                                                            11,
                                                                        fontFamily:
                                                                            'Roboto',
                                                                      ),
                                                                    ),
                                                                    const SizedBox(
                                                                      height:
                                                                          20,
                                                                    ),
                                                                    Row(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .spaceBetween,
                                                                      children: [
                                                                        Row(
                                                                          children: [
                                                                            const SizedBox(
                                                                              width: 10,
                                                                            ),
                                                                            CircleAvatar(
                                                                              radius: 10,
                                                                              backgroundColor: edit == false ? kGreen1 : const Color(0xffAAAAAA),
                                                                            ),
                                                                            const SizedBox(
                                                                              width: 10,
                                                                            ),
                                                                            CircleAvatar(
                                                                              radius: 10,
                                                                              backgroundColor: edit == true ? kGreen1 : const Color(0xffAAAAAA),
                                                                            ),
                                                                            const SizedBox(
                                                                              width: 10,
                                                                            ),
                                                                          ],
                                                                        ),
                                                                        Row(
                                                                          children: [
                                                                            GestureDetector(
                                                                              onTap: () {
                                                                                setState(() {
                                                                                  edit = true;
                                                                                });
                                                                              },
                                                                              child: Container(
                                                                                height: Get.height * 0.05,
                                                                                width: Get.width * 0.30,
                                                                                decoration: BoxDecoration(color: kGreen1, borderRadius: BorderRadius.circular(15)),
                                                                                child: const Center(
                                                                                  child: Text(
                                                                                    'Save & Continue',
                                                                                    style: TextStyle(color: Colors.white, fontFamily: 'Poppins', fontSize: 11),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            )
                                                          : Container(
                                                              width: Get.width,
                                                              child: Column(
                                                                children: [
                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceBetween,
                                                                    children: [
                                                                      const Flexible(
                                                                        child:
                                                                            Text(
                                                                          'Residential Address (As mentioned on the passport)',
                                                                          style:
                                                                              TextStyle(
                                                                            color:
                                                                                kNavy,
                                                                            fontFamily:
                                                                                "Poppins",
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Flexible(
                                                                        child:
                                                                            Container(
                                                                          height:
                                                                              Get.height * 0.04,
                                                                          width:
                                                                              Get.width * 0.08,
                                                                          decoration:
                                                                              BoxDecoration(
                                                                            color:
                                                                                kRed,
                                                                            borderRadius:
                                                                                BorderRadius.circular(8),
                                                                          ),
                                                                          child:
                                                                              const Icon(
                                                                            Icons.close,
                                                                            color:
                                                                                Colors.white,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                  const SizedBox(
                                                                    height: 20,
                                                                  ),
                                                                  commontextfiled(
                                                                      labelText:
                                                                          Text(
                                                                        'Address *',
                                                                        style:
                                                                            TextStyle(
                                                                          color: Colors
                                                                              .black
                                                                              .withOpacity(0.2),
                                                                        ),
                                                                      ),
                                                                      hintText:
                                                                          'Mumbai Chembur'),
                                                                  const SizedBox(
                                                                    height: 20,
                                                                  ),
                                                                  DropdownButtonHideUnderline(
                                                                    child: DropdownButtonFormField(
                                                                        decoration: InputDecoration(
                                                                          labelText:
                                                                              'Country *',
                                                                          border:
                                                                              OutlineInputBorder(
                                                                            borderRadius:
                                                                                BorderRadius.circular(15),
                                                                          ),
                                                                        ),
                                                                        borderRadius: BorderRadius.circular(5),
                                                                        hint: const Text("india"),
                                                                        value: selectedCountry1,
                                                                        items: _country1.map((tile) {
                                                                          return DropdownMenuItem(
                                                                              value: tile,
                                                                              child: Text(
                                                                                tile,
                                                                                style: const TextStyle(color: kGrey4, fontFamily: "Roboto", fontSize: 13),
                                                                              ));
                                                                        }).toList(),
                                                                        onChanged: (newValue) {
                                                                          setState(
                                                                              () {
                                                                            selectedCountry1 =
                                                                                newValue as String?;
                                                                          });
                                                                        }),
                                                                  ),
                                                                  const SizedBox(
                                                                    height: 20,
                                                                  ),
                                                                  DropdownButtonHideUnderline(
                                                                    child: DropdownButtonFormField(
                                                                        decoration: InputDecoration(
                                                                          labelText:
                                                                              'Province/State *',
                                                                          border:
                                                                              OutlineInputBorder(
                                                                            borderRadius:
                                                                                BorderRadius.circular(15),
                                                                          ),
                                                                        ),
                                                                        borderRadius: BorderRadius.circular(5),
                                                                        hint: const Text("Gujrat"),
                                                                        value: selectedState,
                                                                        items: _state.map((tile) {
                                                                          return DropdownMenuItem(
                                                                              value: tile,
                                                                              child: Text(
                                                                                tile,
                                                                                style: const TextStyle(color: kGrey4, fontFamily: "Roboto", fontSize: 13),
                                                                              ));
                                                                        }).toList(),
                                                                        onChanged: (newValue) {
                                                                          setState(
                                                                              () {
                                                                            selectedState =
                                                                                newValue as String?;
                                                                          });
                                                                        }),
                                                                  ),
                                                                  const SizedBox(
                                                                    height: 20,
                                                                  ),
                                                                  commontextfiled(
                                                                      labelText:
                                                                          Text(
                                                                        'City/Town *',
                                                                        style:
                                                                            TextStyle(
                                                                          color: Colors
                                                                              .black
                                                                              .withOpacity(0.2),
                                                                        ),
                                                                      ),
                                                                      hintText:
                                                                          'chandigarh'),
                                                                  const SizedBox(
                                                                    height: 20,
                                                                  ),
                                                                  commontextfiled(
                                                                      labelText:
                                                                          Text(
                                                                        'Postal/Zip Code',
                                                                        style:
                                                                            TextStyle(
                                                                          color: Colors
                                                                              .black
                                                                              .withOpacity(0.2),
                                                                        ),
                                                                      ),
                                                                      hintText:
                                                                          '160004'),
                                                                  const SizedBox(
                                                                    height: 20,
                                                                  ),
                                                                  const Text(
                                                                    'Mailing Address(Current residence address)',
                                                                    style:
                                                                        TextStyle(
                                                                      color:
                                                                          kNavy,
                                                                      fontSize:
                                                                          14,
                                                                    ),
                                                                  ),
                                                                  CheckboxListTile(
                                                                    activeColor:
                                                                        Colors
                                                                            .orange,
                                                                    controlAffinity:
                                                                        ListTileControlAffinity
                                                                            .leading,
                                                                    title: const Text(
                                                                        'Same as above'),
                                                                    value:
                                                                        _checkboxListTile,
                                                                    onChanged:
                                                                        (value) {
                                                                      setState(
                                                                          () {
                                                                        _checkboxListTile =
                                                                            !_checkboxListTile;
                                                                      });
                                                                    },
                                                                  ),
                                                                  const SizedBox(
                                                                    height: 20,
                                                                  ),
                                                                  commontextfiled(
                                                                      labelText:
                                                                          Text(
                                                                        'Address',
                                                                        style:
                                                                            TextStyle(
                                                                          color: Colors
                                                                              .black
                                                                              .withOpacity(0.2),
                                                                        ),
                                                                      ),
                                                                      hintText:
                                                                          'H no453,'),
                                                                  const SizedBox(
                                                                    height: 20,
                                                                  ),
                                                                  DropdownButtonHideUnderline(
                                                                    child: DropdownButtonFormField(
                                                                        decoration: InputDecoration(
                                                                          border:
                                                                              OutlineInputBorder(
                                                                            borderRadius:
                                                                                BorderRadius.circular(15),
                                                                          ),
                                                                        ),
                                                                        borderRadius: BorderRadius.circular(5),
                                                                        hint: const Text("Country"),
                                                                        value: selectedCountry2,
                                                                        items: _country2.map((tile) {
                                                                          return DropdownMenuItem(
                                                                              value: tile,
                                                                              child: Text(
                                                                                tile,
                                                                                style: const TextStyle(color: kGrey4, fontFamily: "Roboto", fontSize: 13),
                                                                              ));
                                                                        }).toList(),
                                                                        onChanged: (newValue) {
                                                                          setState(
                                                                              () {
                                                                            selectedCountry2 =
                                                                                newValue as String?;
                                                                          });
                                                                        }),
                                                                  ),
                                                                  const SizedBox(
                                                                    height: 20,
                                                                  ),
                                                                  DropdownButtonHideUnderline(
                                                                    child: DropdownButtonFormField(
                                                                        decoration: InputDecoration(
                                                                          border:
                                                                              OutlineInputBorder(
                                                                            borderRadius:
                                                                                BorderRadius.circular(15),
                                                                          ),
                                                                        ),
                                                                        borderRadius: BorderRadius.circular(5),
                                                                        hint: const Text("province/State"),
                                                                        value: selectedState1,
                                                                        items: _state1.map((tile) {
                                                                          return DropdownMenuItem(
                                                                              value: tile,
                                                                              child: Text(
                                                                                tile,
                                                                                style: const TextStyle(color: kGrey4, fontFamily: "Roboto", fontSize: 13),
                                                                              ));
                                                                        }).toList(),
                                                                        onChanged: (newValue) {
                                                                          setState(
                                                                              () {
                                                                            selectedState1 =
                                                                                newValue as String?;
                                                                          });
                                                                        }),
                                                                  ),
                                                                  const SizedBox(
                                                                    height: 20,
                                                                  ),
                                                                  commontextfiled(
                                                                      labelText:
                                                                          Text(
                                                                        'City/Town',
                                                                        style:
                                                                            TextStyle(
                                                                          color: Colors
                                                                              .black
                                                                              .withOpacity(0.2),
                                                                        ),
                                                                      ),
                                                                      hintText:
                                                                          'chandigarh'),
                                                                  const SizedBox(
                                                                    height: 20,
                                                                  ),
                                                                  commontextfiled(
                                                                      labelText:
                                                                          Text(
                                                                        'Postal/Zip Code',
                                                                        style:
                                                                            TextStyle(
                                                                          color: Colors
                                                                              .black
                                                                              .withOpacity(0.2),
                                                                        ),
                                                                      ),
                                                                      hintText:
                                                                          '160004'),
                                                                  const SizedBox(
                                                                    height: 20,
                                                                  ),
                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceBetween,
                                                                    children: [
                                                                      Row(
                                                                        children: [
                                                                          const SizedBox(
                                                                            width:
                                                                                10,
                                                                          ),
                                                                          CircleAvatar(
                                                                            radius:
                                                                                10,
                                                                            backgroundColor: edit == false
                                                                                ? kGreen1
                                                                                : const Color(0xffAAAAAA),
                                                                          ),
                                                                          const SizedBox(
                                                                            width:
                                                                                10,
                                                                          ),
                                                                          CircleAvatar(
                                                                            radius:
                                                                                10,
                                                                            backgroundColor: edit == true
                                                                                ? kGreen1
                                                                                : const Color(0xffAAAAAA),
                                                                          ),
                                                                          const SizedBox(
                                                                            width:
                                                                                10,
                                                                          ),
                                                                        ],
                                                                      ),
                                                                      Row(
                                                                        children: [
                                                                          Row(
                                                                            children: [
                                                                              GestureDetector(
                                                                                onTap: () {
                                                                                  setState(() {
                                                                                    edit = false;
                                                                                  });
                                                                                },
                                                                                child: SvgPicture.asset(
                                                                                  'assets/icons/back.svg',
                                                                                  height: 22,
                                                                                  width: 22,
                                                                                ),
                                                                              ),
                                                                              const SizedBox(
                                                                                width: 10,
                                                                              ),
                                                                              const Text(
                                                                                'Back',
                                                                                style: TextStyle(color: kGrey5, fontFamily: 'Poppins', fontWeight: FontWeight.w500, fontSize: 16),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                          GestureDetector(
                                                                            onTap:
                                                                                () {
                                                                              setState(() {
                                                                                edit = true;
                                                                              });
                                                                            },
                                                                            child:
                                                                                Container(
                                                                              height: Get.height * 0.05,
                                                                              width: Get.width * 0.25,
                                                                              decoration: BoxDecoration(color: kGreen1, borderRadius: BorderRadius.circular(15)),
                                                                              child: const Center(
                                                                                child: Text(
                                                                                  'Save',
                                                                                  style: TextStyle(color: Colors.white, fontFamily: 'Poppins', fontSize: 11),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                    ),
                                                  ],
                                                );
                                              },
                                            );
                                          });
                                    },
                                    child: Container(
                                      height: Get.height * 0.035,
                                      width: Get.width * 0.07,
                                      decoration: BoxDecoration(
                                          borderRadius: const BorderRadius.only(
                                            topRight: Radius.circular(7),
                                            bottomRight: Radius.circular(7),
                                            topLeft: Radius.circular(7),
                                          ),
                                          border:
                                              Border.all(color: Colors.black)),
                                      child: const Icon(
                                        Icons.edit,
                                        color: Colors.black,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Stack(
                                children: [
                                  SvgPicture.asset(
                                      'assets/icons/square_empty_agent.svg'),
                                  Positioned(
                                    bottom: 0,
                                    right: 0,
                                    child: Container(
                                        height: 25,
                                        width: 25,
                                        decoration: BoxDecoration(
                                          color: Colors.red,
                                          borderRadius:
                                              BorderRadius.circular(5),
                                        ),
                                        child: const Icon(
                                          Icons.edit,
                                          color: Colors.white,
                                        )),
                                  ),
                                ],
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Text(
                                '${resp.genInfo!.firstName} ${resp.genInfo!.lastName}',
                                style: const TextStyle(
                                  color: kNavy,
                                  fontSize: 20,
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Text(
                                    'MSM ID:',
                                    style: TextStyle(
                                      color: Color(0xff565656),
                                      fontSize: 14,
                                      fontFamily: 'Roboto',
                                    ),
                                  ),
                                  Text(
                                    '${resp.genInfo!.studentId}',
                                    style: const TextStyle(
                                      color: Color(0xff565656),
                                      fontSize: 14,
                                      fontFamily: 'Roboto',
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Padding(
                                padding: const EdgeInsets.all(10),
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                        SvgPicture.asset(
                                            'assets/icons/birthday.svg'),
                                        const SizedBox(
                                          width: 15,
                                        ),
                                        const Text(
                                          'Date Of Birth:',
                                          style: TextStyle(
                                            color: kGrey,
                                            fontSize: 14,
                                            fontFamily: 'Roboto',
                                          ),
                                        ),
                                        Text(
                                          '${resp.genInfo!.dateOfBirth}',
                                          style: const TextStyle(
                                            color: kGrey,
                                            fontSize: 14,
                                            fontFamily: 'Roboto',
                                          ),
                                        )
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    Row(
                                      children: [
                                        SvgPicture.asset(
                                            'assets/icons/gender.svg'),
                                        const SizedBox(
                                          width: 15,
                                        ),
                                        const Text(
                                          'Gender:',
                                          style: TextStyle(
                                            color: kGrey,
                                            fontSize: 14,
                                            fontFamily: 'Roboto',
                                          ),
                                        ),
                                        Text(
                                          '${resp.genInfo!.gender}',
                                          style: const TextStyle(
                                            color: kGrey,
                                            fontSize: 14,
                                            fontFamily: 'Roboto',
                                          ),
                                        )
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    Row(
                                      children: [
                                        SvgPicture.asset(
                                            'assets/icons/language.svg'),
                                        const SizedBox(
                                          width: 15,
                                        ),
                                        const Text(
                                          'Language:',
                                          style: TextStyle(
                                            color: kGrey,
                                            fontSize: 14,
                                            fontFamily: 'Roboto',
                                          ),
                                        ),
                                        Text(
                                          '${resp.genInfo!.language}',
                                          style: const TextStyle(
                                            color: kGrey,
                                            fontSize: 14,
                                            fontFamily: 'Roboto',
                                          ),
                                        )
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    Row(
                                      children: [
                                        SvgPicture.asset(
                                            'assets/icons/citizenship.svg'),
                                        const SizedBox(
                                          width: 15,
                                        ),
                                        const Text(
                                          'Citizenship:',
                                          style: TextStyle(
                                            color: kGrey,
                                            fontSize: 14,
                                            fontFamily: 'Roboto',
                                          ),
                                        ),
                                        Text(
                                          '${resp.genInfo!.citizenship}',
                                          style: const TextStyle(
                                            color: kGrey,
                                            fontSize: 14,
                                            fontFamily: 'Roboto',
                                          ),
                                        )
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    Row(
                                      children: [
                                        SvgPicture.asset(
                                            'assets/icons/passport.svg'),
                                        const SizedBox(
                                          width: 15,
                                        ),
                                        const Text(
                                          'Passport:',
                                          style: TextStyle(
                                            color: kGrey,
                                            fontSize: 14,
                                            fontFamily: 'Roboto',
                                          ),
                                        ),
                                        Text(
                                          '${resp.genInfo!.passportNo}',
                                          style: const TextStyle(
                                            color: kGrey,
                                            fontSize: 14,
                                            fontFamily: 'Roboto',
                                          ),
                                        )
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    Row(
                                      children: [
                                        SvgPicture.asset(
                                            'assets/icons/passport.svg'),
                                        const SizedBox(
                                          width: 15,
                                        ),
                                        const Text(
                                          'Expriry Date:',
                                          style: TextStyle(
                                            color: kGrey,
                                            fontSize: 14,
                                            fontFamily: 'Roboto',
                                          ),
                                        ),
                                        Text(
                                          '${resp.genInfo!.passportExpiryDate}',
                                          style: const TextStyle(
                                            color: kGrey,
                                            fontSize: 14,
                                            fontFamily: 'Roboto',
                                          ),
                                        )
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    Row(
                                      children: [
                                        SvgPicture.asset(
                                            'assets/icons/email1.svg'),
                                        const SizedBox(
                                          width: 15,
                                        ),
                                        Text(
                                          '${resp.genInfo!.email}',
                                          style: const TextStyle(
                                            color: kGrey,
                                            fontSize: 14,
                                            fontFamily: 'Roboto',
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    Row(
                                      children: [
                                        SvgPicture.asset(
                                            'assets/icons/phone.svg'),
                                        const SizedBox(
                                          width: 15,
                                        ),
                                        const Text(
                                          'Contact:',
                                          style: TextStyle(
                                            color: kGrey,
                                            fontSize: 14,
                                            fontFamily: 'Roboto',
                                          ),
                                        ),
                                        Text(
                                          '${resp.genInfo!.mobileNo}',
                                          style: const TextStyle(
                                            color: kGrey,
                                            fontSize: 14,
                                            fontFamily: 'Roboto',
                                          ),
                                        )
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    Row(
                                      children: [
                                        SvgPicture.asset(
                                            'assets/icons/agent.svg'),
                                        const SizedBox(
                                          width: 15,
                                        ),
                                        const Text(
                                          'Agent/Recruiter:',
                                          style: TextStyle(
                                            color: kGrey,
                                            fontSize: 14,
                                            fontFamily: 'Roboto',
                                          ),
                                        ),
                                        Text(
                                          '${resp.genInfo!.agentName}',
                                          style: const TextStyle(
                                            color: kGrey,
                                            fontSize: 14,
                                            fontFamily: 'Roboto',
                                          ),
                                        )
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    Row(
                                      children: [
                                        SvgPicture.asset(
                                            'assets/icons/residential.svg'),
                                        const SizedBox(
                                          width: 15,
                                        ),
                                        const Text(
                                          'Residential Address:',
                                          style: TextStyle(
                                            color: kGrey,
                                            fontSize: 14,
                                            fontFamily: 'Roboto',
                                          ),
                                        ),
                                        Text(
                                          '${resp.genInfo!.addres}',
                                          style: const TextStyle(
                                            color: kGrey,
                                            fontSize: 14,
                                            fontFamily: 'Roboto',
                                          ),
                                        )
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    Row(
                                      children: [
                                        SvgPicture.asset(
                                            'assets/icons/mailingaddress.svg'),
                                        const SizedBox(
                                          width: 15,
                                        ),
                                        const Text(
                                          'Mailing Address:',
                                          style: TextStyle(
                                            color: kGrey,
                                            fontSize: 14,
                                            fontFamily: 'Roboto',
                                          ),
                                        ),
                                        Text(
                                          '${resp.genInfo!.mailingAddres}',
                                          style: const TextStyle(
                                            color: kGrey,
                                            fontSize: 14,
                                            fontFamily: 'Roboto',
                                          ),
                                        )
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Align(
                                alignment: Alignment.centerRight,
                                child: GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      emergency = true;
                                    });
                                  },
                                  child: Container(
                                    height: Get.height * 0.045,
                                    width: Get.width * 0.40,
                                    decoration: BoxDecoration(
                                        color: const Color(0xff565656),
                                        borderRadius:
                                            BorderRadius.circular(10)),
                                    child: const Center(
                                      child: Text(
                                        'Emergency Contact ',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 11,
                                          fontFamily: 'Roboto',
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                            ],
                          ),
                        ),
                        emergency == false
                            ? SliverToBoxAdapter(
                                child: TabBar(
                                  controller: _tabController,
                                  isScrollable: true,
                                  unselectedLabelColor: Colors.black,
                                  indicatorColor: Colors.red,
                                  labelColor: Colors.red,
                                  tabs: const [
                                    Tab(
                                      child: Text('Education'),
                                    ),
                                    Tab(
                                      child: Text('Test Scores'),
                                    ),
                                    Tab(
                                      child: Text('Documents'),
                                    ),
                                    Tab(
                                      child: Text('Student Visa'),
                                    ),
                                    Tab(
                                      child: Text('Interest'),
                                    ),
                                    Tab(
                                      child: Text('Application'),
                                    ),
                                    Tab(
                                      child: Text('Note'),
                                    ),
                                  ],
                                ),
                              )
                            : const SliverToBoxAdapter(
                                child: SizedBox(),
                              ),
                      ];
                    },
                    body: emergency == false
                        ? TabBarView(
                            controller: _tabController,
                            children: [
                              StudentEducationTab(data: resp),
                              const StdTestScoreTab(),
                              const StudentEditDocumentTabScreen(),
                              const StudentVisaTab(),
                              const StdInterestTab(),
                              StdApplicationScreen(data: resp),
                              const StdNoteTab(),
                            ],
                          )
                        : SingleChildScrollView(
                            child: Column(
                              children: [
                                const SizedBox(
                                  height: 15,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      children: [
                                        GestureDetector(
                                          onTap: () {
                                            setState(() {
                                              emergency = false;
                                            });
                                          },
                                          child: SvgPicture.asset(
                                            'assets/icons/back.svg',
                                            height: 22,
                                            width: 22,
                                          ),
                                        ),
                                        const SizedBox(
                                          width: 10,
                                        ),
                                        const Text(
                                          'Back',
                                          style: TextStyle(
                                              color: kGrey5,
                                              fontFamily: 'Poppins',
                                              fontWeight: FontWeight.w500,
                                              fontSize: 16),
                                        ),
                                      ],
                                    ),
                                    Container(
                                      height: Get.height * 0.035,
                                      width: Get.width * 0.07,
                                      decoration: BoxDecoration(
                                          borderRadius: const BorderRadius.only(
                                            topRight: Radius.circular(7),
                                            bottomRight: Radius.circular(7),
                                            topLeft: Radius.circular(7),
                                          ),
                                          border:
                                              Border.all(color: Colors.black)),
                                      child: const Icon(
                                        Icons.edit,
                                        color: Colors.black,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  height: 15,
                                ),
                                Container(
                                  padding: const EdgeInsets.all(15),
                                  height: Get.height * 0.18,
                                  width: Get.width,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: const Color(0xffF4F5F7)),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: const [
                                      Text(
                                        'Name',
                                        style: TextStyle(
                                            color: Color(0xff79747E),
                                            fontSize: 15,
                                            fontFamily: 'Poppins'),
                                      ),
                                      SizedBox(
                                        height: 5,
                                      ),
                                      Text(
                                        '9821611851',
                                        style: TextStyle(
                                            color: Color(0xff192A3E),
                                            fontSize: 15,
                                            fontFamily: 'Poppins'),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(
                                  height: 15,
                                ),
                                Container(
                                  padding: const EdgeInsets.all(15),
                                  height: Get.height * 0.18,
                                  width: Get.width,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: const Color(0xffF4F5F7)),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: const [
                                      Text(
                                        'Email ID',
                                        style: TextStyle(
                                            color: Color(0xff79747E),
                                            fontSize: 15,
                                            fontFamily: 'Poppins'),
                                      ),
                                      SizedBox(
                                        height: 5,
                                      ),
                                      Text(
                                        'omojha9999@gmail.com',
                                        style: TextStyle(
                                            color: Color(0xff192A3E),
                                            fontSize: 15,
                                            fontFamily: 'Poppins'),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(
                                  height: 15,
                                ),
                                Container(
                                  padding: const EdgeInsets.all(15),
                                  height: Get.height * 0.18,
                                  width: Get.width,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: const Color(0xffF4F5F7)),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: const [
                                      Text(
                                        'Relation',
                                        style: TextStyle(
                                            color: Color(0xff79747E),
                                            fontSize: 15,
                                            fontFamily: 'Poppins'),
                                      ),
                                      SizedBox(
                                        height: 5,
                                      ),
                                      Text(
                                        'Son',
                                        style: TextStyle(
                                            color: Color(0xff192A3E),
                                            fontSize: 15,
                                            fontFamily: 'Poppins'),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(
                                  height: 15,
                                ),
                                Container(
                                  padding: const EdgeInsets.all(15),
                                  height: Get.height * 0.18,
                                  width: Get.width,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: const Color(0xffF4F5F7)),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: const [
                                      Text(
                                        'Home Phone',
                                        style: TextStyle(
                                            color: Color(0xff79747E),
                                            fontSize: 15,
                                            fontFamily: 'Poppins'),
                                      ),
                                      SizedBox(
                                        height: 5,
                                      ),
                                      Text(
                                        '+91',
                                        style: TextStyle(
                                            color: Color(0xff192A3E),
                                            fontSize: 15,
                                            fontFamily: 'Poppins'),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(
                                  height: 15,
                                ),
                                Container(
                                  padding: const EdgeInsets.all(15),
                                  height: Get.height * 0.18,
                                  width: Get.width,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: const Color(0xffF4F5F7)),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: const [
                                      Text(
                                        'Cell Phone',
                                        style: TextStyle(
                                            color: Color(0xff79747E),
                                            fontSize: 15,
                                            fontFamily: 'Poppins'),
                                      ),
                                      SizedBox(
                                        height: 5,
                                      ),
                                      Text(
                                        '0845183547',
                                        style: TextStyle(
                                            color: Color(0xff192A3E),
                                            fontSize: 15,
                                            fontFamily: 'Poppins'),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(
                                  height: 15,
                                ),
                                Container(
                                  padding: const EdgeInsets.all(15),
                                  height: Get.height * 0.18,
                                  width: Get.width,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: const Color(0xffF4F5F7)),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: const [
                                      Text(
                                        'Business Phone',
                                        style: TextStyle(
                                            color: Color(0xff79747E),
                                            fontSize: 15,
                                            fontFamily: 'Poppins'),
                                      ),
                                      SizedBox(
                                        height: 5,
                                      ),
                                      Text(
                                        '845181357441',
                                        style: TextStyle(
                                            color: Color(0xff192A3E),
                                            fontSize: 15,
                                            fontFamily: 'Poppins'),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(
                                  height: 15,
                                ),
                                supportSection(),
                              ],
                            ),
                          ),
                  );
                } else {
                  if (controller.apiResponse.status == Status.ERROR) {
                    return const CircularProgressIndicator();
                  }
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                }
              },
            ),
          ),
        ),
      ),
    );
  }
}
