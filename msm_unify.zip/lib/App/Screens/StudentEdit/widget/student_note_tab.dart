import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:msm_unify/App/common/AppConfig/support_section.dart';

import '../../../common/color_constant.dart';

class StdNoteTab extends StatefulWidget {
  const StdNoteTab({Key? key}) : super(key: key);

  @override
  State<StdNoteTab> createState() => _StdNoteTabState();
}

class _StdNoteTabState extends State<StdNoteTab> {
  final _comment = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Column(
              children: [
                Row(
                  children: const [
                    Text(
                      "Student's Comments",
                      style: TextStyle(
                          color: kNavy,
                          fontFamily: 'Poppins',
                          fontSize: 18,
                          fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
                Container(
                  height: Get.height * 0.2,
                  width: double.infinity,
                  decoration: BoxDecoration(
                      border: Border.all(color: kGrey4),
                      borderRadius: BorderRadius.circular(10)),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    child: TextFormField(
                      controller: _comment,
                      cursorColor: kRed,
                      decoration: InputDecoration(
                          hintStyle: TextStyle(
                              color: Colors.black.withOpacity(0.2),
                              fontFamily: 'Roboto'),
                          hintText: 'Write your notes here.....',
                          border: InputBorder.none),
                    ),
                  ),
                ),
                SizedBox(
                  height: Get.height * 0.005,
                ),
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        'Comments will be emailed to the Admission Executive.',
                        style: TextStyle(
                            color: Colors.black.withOpacity(0.5),
                            fontFamily: 'Roboto',
                            fontSize: 13),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: Get.height * 0.05,
                ),
                GestureDetector(
                  onTap: () {},
                  child: Container(
                    padding: EdgeInsets.all(10),
                    height: Get.height * 0.05,
                    width: Get.width * 0.29,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        border:
                            Border.all(color: kNavy, style: BorderStyle.solid)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: const [
                        Icon(
                          Icons.add,
                          color: kNavy,
                        ),
                        Flexible(
                          child: Text(
                            'Add More',
                            style: TextStyle(
                              color: kNavy,
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: Get.height * 0.07,
                ),
                Row(
                  children: const [
                    Text(
                      'Student logged/ 15 May 2022 /Jay',
                      style: TextStyle(
                          fontFamily: 'Roboto', fontSize: 16, color: kRed),
                    )
                  ],
                ),
                const Divider(),
                Row(
                  children: [
                    Text(
                      'Student logged',
                      style: TextStyle(
                          fontFamily: 'Roboto',
                          fontSize: 18,
                          color: Colors.black.withOpacity(0.6)),
                    )
                  ],
                ),
                SizedBox(
                  height: Get.height * 0.38,
                ),
                supportSection(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
