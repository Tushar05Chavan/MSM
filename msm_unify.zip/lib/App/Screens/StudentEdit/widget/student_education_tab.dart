import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:msm_unify/model/responseModek/student_view_response_model.dart';
import 'package:msm_unify/viewModel/country_dropdown_view_model.dart';
import 'package:msm_unify/viewModel/level_of_education_view_model.dart';

import '../../../../model/responseModek/country_dropdown_response_model.dart';
import '../../../../model/responseModek/grade_response_model.dart';
import '../../../../model/responseModek/level_of_education_response_model.dart';
import '../../../../viewModel/grade_view_model.dart';
import '../../../common/AppConfig/support_section.dart';
import '../../../common/color_constant.dart';

class StudentEducationTab extends StatefulWidget {
  final StudentViewResponseModel? data;

  const StudentEducationTab({Key? key, this.data}) : super(key: key);

  @override
  State<StudentEducationTab> createState() => _StudentEducationTabState();
}

class _StudentEducationTabState extends State<StudentEducationTab> {
  final TextEditingController _startDate = TextEditingController();

  final TextEditingController _endDate = TextEditingController();
  final TextEditingController _degreeawarded = TextEditingController();

  String? _selectedGradeEducation;
  String? _selectedLevelOfEducation;
  String? _selectedPrimaryLanguage;
  String? _selectedProvince;
  String? _selectedCountryInstitution;
  final List<String> _countryInstitution = ['India', 'Pakistan', 'USA', 'UK'];
  final List<String> _primaryLanguage = ['Hindi', 'Gujrati', 'Desi', 'Videsi'];
  final List<String> _province = [
    'paktila',
    'Simada',
    'Varachha',
    'Motavarachha'
  ];

  final List<String> _degreeEducation = [
    'Yemen',
    'India',
    "USA",
    "Afghanistan",
    "Argentina"
  ];
  final DateFormat formatter = DateFormat('dd-MM-yyyy');

  final LevelOfEducationViewModel _levelOfEducationViewModel =
      Get.put(LevelOfEducationViewModel());

  List<LevelOfEducationResponseModel> levelOfEdu = [];
  Future<void> getLevelOfEducation() async {
    await _levelOfEducationViewModel.levelOfEducationViewModel();
    List<LevelOfEducationResponseModel> response =
        _levelOfEducationViewModel.apiResponse.data;
    response.forEach((element) {
      levelOfEdu.add(element);
    });
  }

  final GradeViewModel _gradeViewModel = Get.put(GradeViewModel());
  List<GradeResponseModel> grades = [];
  Future<void> getGrade() async {
    await _gradeViewModel.gradeViewModel();
    List<GradeResponseModel> response = _gradeViewModel.apiResponse.data;
    response.forEach((element) {
      grades.add(element);
    });
    setState(() {});
  }

  final CountryDropViewModel countryDropViewModel =
      Get.put(CountryDropViewModel());

  String? _selectedCountryEducation;
  List<CountryDropResponseModel> countries = [];
  Future<void> getCountry() async {
    await countryDropViewModel.countryDropViewModel();
    List<CountryDropResponseModel> response =
        countryDropViewModel.apiResponse.data;

    response.forEach((element) {
      countries.add(element);
    });
    setState(() {});
  }

  @override
  void initState() {
    getCountry();
    getLevelOfEducation();
    getGrade();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 20,
                ),
                DropdownButtonHideUnderline(
                  child: DropdownButtonFormField(
                      decoration: InputDecoration(
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(15))),
                      validator: (title) {
                        if (title != null) {
                          return "Please Enter Title";
                        }
                      },
                      borderRadius: BorderRadius.circular(5),
                      hint: Text(
                          "${widget.data!.eduInfo!.countryOfEducationName}"),
                      value: _selectedCountryEducation,
                      items: countries.map((countryEducation) {
                        return DropdownMenuItem(
                            value: countryEducation.countryName.toString(),
                            child: Text(
                              countryEducation.countryName.toString(),
                              style: const TextStyle(
                                  color: kGrey4,
                                  fontFamily: "Roboto",
                                  fontSize: 13),
                            ));
                      }).toList(),
                      onChanged: (newValue) {
                        setState(() {
                          _selectedCountryEducation = newValue as String?;
                        });
                      }),
                ),
                const SizedBox(
                  height: 15,
                ),
                DropdownButtonHideUnderline(
                  child: DropdownButtonFormField(
                      isExpanded: true,
                      decoration: InputDecoration(
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(15))),
                      validator: (title) {
                        if (title != null) {
                          return "Level of Education";
                        }
                      },
                      borderRadius: BorderRadius.circular(5),
                      hint: Text(
                          "${widget.data!.eduInfo!.highestLevelOfEducationName}"),
                      value: _selectedLevelOfEducation,
                      items: levelOfEdu.map((levelOfEducation) {
                        return DropdownMenuItem(
                            value: levelOfEducation.eduLevelId.toString(),
                            child: Text(
                              levelOfEducation.eduLevelName.toString(),
                              style: const TextStyle(
                                  color: kGrey4,
                                  fontFamily: "Roboto",
                                  fontSize: 13),
                            ));
                      }).toList(),
                      onChanged: (newValue) {
                        setState(() {
                          _selectedLevelOfEducation = newValue as String?;
                        });
                      }),
                ),
                const SizedBox(
                  height: 15,
                ),
                DropdownButtonHideUnderline(
                  child: DropdownButtonFormField(
                      decoration: InputDecoration(
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(15))),
                      validator: (title) {
                        if (title != null) {
                          return "Please Enter Title";
                        }
                      },
                      borderRadius: BorderRadius.circular(5),
                      hint: Text("${widget.data!.eduInfo!.gradingSchemeName}"),
                      value: _selectedGradeEducation,
                      items: grades.map((gradeEducation) {
                        return DropdownMenuItem(
                            value: gradeEducation.grdSchemeId.toString(),
                            child: Text(
                              gradeEducation.grdSchemeName.toString(),
                              style: const TextStyle(
                                  color: kGrey4,
                                  fontFamily: "Roboto",
                                  fontSize: 13),
                            ));
                      }).toList(),
                      onChanged: (newValue) {
                        setState(() {
                          _selectedGradeEducation = newValue as String?;
                        });
                      }),
                ),
                const SizedBox(
                  height: 15,
                ),
                TextFormField(
                  validator: (grade) {
                    if (grade != null) {
                      return "Please Enter Grade";
                    }
                  },
                  cursorColor: kRed,
                  decoration: InputDecoration(
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide: const BorderSide(
                            color: Colors.black,
                          )),
                      hintStyle: TextStyle(
                          color: Colors.black.withOpacity(0.6),
                          fontFamily: 'Roboto'),
                      hintText: '${widget.data!.eduInfo!.gradeAverage}',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                      )),
                ),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  child: Text(
                    'A+ ,A,A- ,B+ ,B,B- ,C+ ,C,C- ,D+ ,D,D- ,E',
                    style: TextStyle(
                        color: kGrey4, fontFamily: "Roboto", fontSize: 13),
                  ),
                ),
                const SizedBox(
                  height: 15,
                ),
                Align(
                  alignment: Alignment.centerRight,
                  child: Container(
                    height: Get.height * 0.05,
                    width: Get.width * 0.20,
                    decoration: BoxDecoration(
                      color: kGreen1,
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: const Center(
                      child: Text(
                        'Update',
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                const Text(
                  '*10th Grade and 12th Grade details are mandatory',
                  style: TextStyle(
                    color: Color(0xff3C4858),
                    fontSize: 13,
                    fontFamily: 'Roboto',
                  ),
                ),
                const SizedBox(
                  height: 15,
                ),
                Align(
                  alignment: Alignment.centerRight,
                  child: GestureDetector(
                    onTap: () {
                      showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return AlertDialog(
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20),
                                  side: const BorderSide(color: Colors.red)),
                              content: Container(
                                height: Get.height * 0.70,
                                width: Get.width,
                                child: SingleChildScrollView(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          const Text(
                                            'Add School Details',
                                            style: TextStyle(
                                                color: kNavy,
                                                fontFamily: 'Poppins',
                                                fontWeight: FontWeight.w600),
                                          ),
                                          GestureDetector(
                                            onTap: () {
                                              Get.back();
                                            },
                                            child: Container(
                                              height: Get.height * 0.04,
                                              width: Get.width * 0.08,
                                              decoration: BoxDecoration(
                                                color: kRed,
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                              ),
                                              child: const Icon(
                                                Icons.close,
                                                color: Colors.white,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(
                                        height: 15,
                                      ),
                                      DropdownButtonHideUnderline(
                                        child: DropdownButtonFormField(
                                            decoration: InputDecoration(
                                                border: OutlineInputBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            15))),
                                            validator: (title) {
                                              if (title != null) {
                                                return "Level of Education";
                                              }
                                            },
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            hint: const Text(
                                                "Level Of Education"),
                                            value: _selectedLevelOfEducation,
                                            items: _degreeEducation
                                                .map((levelOfEducation) {
                                              return DropdownMenuItem(
                                                  value: levelOfEducation,
                                                  child: Text(
                                                    levelOfEducation,
                                                    style: TextStyle(
                                                        color: Colors.black
                                                            .withOpacity(0.2),
                                                        fontFamily: "Roboto",
                                                        fontSize: 13),
                                                  ));
                                            }).toList(),
                                            onChanged: (newValue) {
                                              setState(() {
                                                _selectedLevelOfEducation =
                                                    newValue as String?;
                                              });
                                            }),
                                      ),
                                      const SizedBox(
                                        height: 15,
                                      ),
                                      DropdownButtonHideUnderline(
                                        child: DropdownButtonFormField(
                                            decoration: InputDecoration(
                                                border: OutlineInputBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            15))),
                                            validator: (title) {
                                              if (title != null) {
                                                return "Country of institution";
                                              }
                                            },
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            hint: const Text(
                                                "Country of institution"),
                                            value: _selectedCountryInstitution,
                                            items: _countryInstitution
                                                .map((countryInstitution) {
                                              return DropdownMenuItem(
                                                  value: countryInstitution,
                                                  child: Text(
                                                    countryInstitution,
                                                    style: TextStyle(
                                                        color: Colors.black
                                                            .withOpacity(0.2),
                                                        fontFamily: "Roboto",
                                                        fontSize: 13),
                                                  ));
                                            }).toList(),
                                            onChanged: (newValue) {
                                              setState(() {
                                                _selectedCountryInstitution =
                                                    newValue as String?;
                                              });
                                            }),
                                      ),
                                      const SizedBox(
                                        height: 15,
                                      ),
                                      TextFormField(
                                        validator: (fName) {
                                          if (fName != null) {
                                            return "Name Of Institution";
                                          }
                                        },
                                        cursorColor: kRed,
                                        decoration: InputDecoration(
                                            focusedBorder: OutlineInputBorder(
                                                borderRadius:
                                                    BorderRadius.circular(15),
                                                borderSide: const BorderSide(
                                                  color: Colors.black,
                                                )),
                                            hintStyle: const TextStyle(
                                                color: kGrey4,
                                                fontFamily: 'Roboto'),
                                            hintText: 'Name Of Institution',
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(15),
                                            )),
                                      ),
                                      const SizedBox(
                                        height: 15,
                                      ),
                                      DropdownButtonHideUnderline(
                                        child: DropdownButtonFormField(
                                            decoration: InputDecoration(
                                                border: OutlineInputBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            15))),
                                            validator: (title) {
                                              if (title != null) {
                                                return "select Province";
                                              }
                                            },
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            hint: const Text("Province"),
                                            value: _selectedProvince,
                                            items: _province.map((province) {
                                              return DropdownMenuItem(
                                                  value: province,
                                                  child: Text(
                                                    province,
                                                    style: const TextStyle(
                                                        color: kGrey4,
                                                        fontFamily: "Roboto",
                                                        fontSize: 13),
                                                  ));
                                            }).toList(),
                                            onChanged: (newValue) {
                                              setState(() {
                                                _selectedProvince =
                                                    newValue as String?;
                                              });
                                            }),
                                      ),
                                      const SizedBox(
                                        height: 15,
                                      ),
                                      TextFormField(
                                        validator: (fName) {
                                          if (fName != null) {
                                            return "Name Of City/Town";
                                          }
                                        },
                                        cursorColor: kRed,
                                        decoration: InputDecoration(
                                            focusedBorder: OutlineInputBorder(
                                                borderRadius:
                                                    BorderRadius.circular(15),
                                                borderSide: const BorderSide(
                                                  color: Colors.black,
                                                )),
                                            hintStyle: TextStyle(
                                                color: kGrey4,
                                                fontFamily: 'Roboto'),
                                            hintText: 'City/Town',
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(15),
                                            )),
                                      ),
                                      const SizedBox(
                                        height: 15,
                                      ),
                                      DropdownButtonHideUnderline(
                                        child: DropdownButtonFormField(
                                            decoration: InputDecoration(
                                                border: OutlineInputBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            15))),
                                            validator: (title) {
                                              if (title != null) {
                                                return "select Province";
                                              }
                                            },
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            hint: const Text(
                                                "Primary Language Institution"),
                                            value: _selectedPrimaryLanguage,
                                            items: _primaryLanguage
                                                .map((primaryLanguage) {
                                              return DropdownMenuItem(
                                                  value: primaryLanguage,
                                                  child: Text(
                                                    primaryLanguage,
                                                    style: const TextStyle(
                                                        color: kGrey4,
                                                        fontFamily: "Roboto",
                                                        fontSize: 13),
                                                  ));
                                            }).toList(),
                                            onChanged: (newValue) {
                                              setState(() {
                                                _selectedPrimaryLanguage =
                                                    newValue as String?;
                                              });
                                            }),
                                      ),
                                      const SizedBox(
                                        height: 15,
                                      ),
                                      TextFormField(
                                        controller: _startDate,
                                        cursorColor: kRed,
                                        decoration: InputDecoration(
                                            suffixIcon: IconButton(
                                              icon: Icon(Icons.today),
                                              onPressed: () async {
                                                DateTime date = DateTime(1900);
                                                FocusScope.of(context)
                                                    .requestFocus(FocusNode());

                                                date = (await showDatePicker(
                                                    context: context,
                                                    initialDate: DateTime.now(),
                                                    firstDate: DateTime(1900),
                                                    lastDate: DateTime.now()))!;
                                                _startDate.text =
                                                    formatter.format(date);
                                              },
                                            ),
                                            focusedBorder: OutlineInputBorder(
                                                borderRadius:
                                                    BorderRadius.circular(15),
                                                borderSide: const BorderSide(
                                                  color: Colors.black,
                                                )),
                                            hintStyle: TextStyle(
                                                color: Colors.black
                                                    .withOpacity(0.2),
                                                fontFamily: 'Roboto'),
                                            hintText: 'Start date DD/MM/YYYY',
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(15),
                                            )),
                                      ),
                                      const SizedBox(
                                        height: 15,
                                      ),
                                      TextFormField(
                                        controller: _endDate,
                                        cursorColor: kRed,
                                        decoration: InputDecoration(
                                            suffixIcon: IconButton(
                                              icon: Icon(Icons.today),
                                              onPressed: () async {
                                                DateTime date = DateTime(1900);
                                                FocusScope.of(context)
                                                    .requestFocus(FocusNode());

                                                date = (await showDatePicker(
                                                    context: context,
                                                    initialDate: DateTime.now(),
                                                    firstDate: DateTime(1900),
                                                    lastDate: DateTime.now()))!;
                                                _endDate.text =
                                                    formatter.format(date);
                                              },
                                            ),
                                            focusedBorder: OutlineInputBorder(
                                                borderRadius:
                                                    BorderRadius.circular(15),
                                                borderSide: const BorderSide(
                                                  color: Colors.black,
                                                )),
                                            hintStyle: TextStyle(
                                                color: Colors.black
                                                    .withOpacity(0.2),
                                                fontFamily: 'Roboto'),
                                            hintText: 'End date DD/MM/YYYY',
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(15),
                                            )),
                                      ),
                                      const SizedBox(
                                        height: 15,
                                      ),
                                      TextFormField(
                                        controller: _degreeawarded,
                                        cursorColor: kRed,
                                        decoration: InputDecoration(
                                            suffixIcon: IconButton(
                                              icon: Icon(Icons.today),
                                              onPressed: () async {
                                                DateTime date = DateTime(1900);
                                                FocusScope.of(context)
                                                    .requestFocus(FocusNode());

                                                date = (await showDatePicker(
                                                    context: context,
                                                    initialDate: DateTime.now(),
                                                    firstDate: DateTime(1900),
                                                    lastDate: DateTime.now()))!;
                                                _degreeawarded.text =
                                                    formatter.format(date);
                                              },
                                            ),
                                            focusedBorder: OutlineInputBorder(
                                                borderRadius:
                                                    BorderRadius.circular(15),
                                                borderSide: const BorderSide(
                                                  color: Colors.black,
                                                )),
                                            hintStyle: TextStyle(
                                                color: Colors.black
                                                    .withOpacity(0.2),
                                                fontFamily: 'Roboto'),
                                            hintText:
                                                'Degree awarded date DD/MM/YYYY',
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(15),
                                            )),
                                      ),
                                      const SizedBox(
                                        height: 15,
                                      ),
                                      TextFormField(
                                        validator: (fName) {
                                          if (fName != null) {
                                            return "Name Of Institution";
                                          }
                                        },
                                        cursorColor: kRed,
                                        decoration: InputDecoration(
                                            focusedBorder: OutlineInputBorder(
                                                borderRadius:
                                                    BorderRadius.circular(15),
                                                borderSide: const BorderSide(
                                                  color: Colors.black,
                                                )),
                                            hintStyle: TextStyle(
                                                color: Colors.black
                                                    .withOpacity(0.2),
                                                fontFamily: 'Roboto'),
                                            hintText:
                                                'Degree awarded/ Program name',
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(15),
                                            )),
                                      ),
                                      const SizedBox(
                                        height: 20,
                                      ),
                                      Align(
                                        alignment: Alignment.center,
                                        child: Container(
                                          height: Get.height * 0.035,
                                          width: Get.width * 0.20,
                                          decoration: BoxDecoration(
                                            color: kRed,
                                            borderRadius:
                                                BorderRadius.circular(10),
                                          ),
                                          child: const Center(
                                            child: Text(
                                              'Add',
                                              style: TextStyle(
                                                  color: Colors.white),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          });
                    },
                    child: Container(
                      padding: EdgeInsets.all(10),
                      height: Get.height * 0.05,
                      width: Get.width * 0.30,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: kNavy)),
                      child: Row(
                        children: const [
                          Icon(
                            Icons.add,
                            color: kNavy,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Flexible(
                            child: Text(
                              'Add More',
                              style: TextStyle(
                                color: kNavy,
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: Get.height * 0.38,
                ),
                supportSection(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
