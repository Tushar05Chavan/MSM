// To parse this JSON data, do
//
//     final applicationProgramOfProgramResponseModel = applicationProgramOfProgramResponseModelFromJson(jsonString);

import 'dart:convert';

List<ApplicationProgramOfProgramResponseModel>
    applicationProgramOfProgramResponseModelFromJson(String str) =>
        List<ApplicationProgramOfProgramResponseModel>.from(json
            .decode(str)
            .map((x) => ApplicationProgramOfProgramResponseModel.fromJson(x)));

String applicationProgramOfProgramResponseModelToJson(
        List<ApplicationProgramOfProgramResponseModel> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class ApplicationProgramOfProgramResponseModel {
  ApplicationProgramOfProgramResponseModel({
    this.programId,
    this.programName,
  });

  int? programId;
  String? programName;

  factory ApplicationProgramOfProgramResponseModel.fromJson(
          Map<String, dynamic> json) =>
      ApplicationProgramOfProgramResponseModel(
        programId: json["ProgramId"],
        programName: json["ProgramName"],
      );

  Map<String, dynamic> toJson() => {
        "ProgramId": programId,
        "ProgramName": programName,
      };
}
