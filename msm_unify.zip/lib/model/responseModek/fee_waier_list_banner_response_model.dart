// To parse this JSON data, do
//
//     final feeWaierListBannerResponseModel = feeWaierListBannerResponseModelFromJson(jsonString);

import 'dart:convert';

List<FeeWaierListBannerResponseModel> feeWaierListBannerResponseModelFromJson(
        String str) =>
    List<FeeWaierListBannerResponseModel>.from(json
        .decode(str)
        .map((x) => FeeWaierListBannerResponseModel.fromJson(x)));

String feeWaierListBannerResponseModelToJson(
        List<FeeWaierListBannerResponseModel> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class FeeWaierListBannerResponseModel {
  FeeWaierListBannerResponseModel({
    this.institutionId,
    this.bannerPath,
  });

  int? institutionId;
  BannerPath? bannerPath;

  factory FeeWaierListBannerResponseModel.fromJson(Map<String, dynamic> json) =>
      FeeWaierListBannerResponseModel(
        institutionId: json["InstitutionId"],
        bannerPath: bannerPathValues.map[json["BannerPath"]],
      );

  Map<String, dynamic> toJson() => {
        "InstitutionId": institutionId,
        "BannerPath": bannerPathValues.reverse![bannerPath],
      };
}

enum BannerPath { THE_6_A9_F8_A29_6992447_C_96_A6_02_A669_F5701_B_PNG }

final bannerPathValues = EnumValues({
  "6a9f8a29-6992-447c-96a6-02a669f5701b.png":
      BannerPath.THE_6_A9_F8_A29_6992447_C_96_A6_02_A669_F5701_B_PNG
});

class EnumValues<T> {
  Map<String, T> map;
  Map<T, String>? reverseMap;

  EnumValues(this.map);

  Map<T, String>? get reverse {
    if (reverseMap == null) {
      reverseMap = map.map((k, v) => new MapEntry(v, k));
    }
    return reverseMap;
  }
}
