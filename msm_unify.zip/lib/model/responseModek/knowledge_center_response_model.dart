// To parse this JSON data, do
//
//     final knowledgeCenterResponseModel = knowledgeCenterResponseModelFromJson(jsonString);

import 'dart:convert';

List<KnowledgeCenterResponseModel> knowledgeCenterResponseModelFromJson(
        String str) =>
    List<KnowledgeCenterResponseModel>.from(
        json.decode(str).map((x) => KnowledgeCenterResponseModel.fromJson(x)));

String knowledgeCenterResponseModelToJson(
        List<KnowledgeCenterResponseModel> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class KnowledgeCenterResponseModel {
  KnowledgeCenterResponseModel({
    this.category,
    this.data,
  });

  Category? category;
  List<Datum>? data;

  factory KnowledgeCenterResponseModel.fromJson(Map<String, dynamic> json) =>
      KnowledgeCenterResponseModel(
        category: categoryValues.map[json["category"]],
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "category": categoryValues.reverse![category],
        "data": List<dynamic>.from(data!.map((x) => x.toJson())),
      };
}

enum Category { MSM_UNIFY_FEATURES_AND_TRAINING_MODULE }

final categoryValues = EnumValues({
  "MSM Unify Features and Training Module":
      Category.MSM_UNIFY_FEATURES_AND_TRAINING_MODULE
});

class Datum {
  Datum({
    this.knowledgeCid,
    this.categoryName,
    this.documentTitle,
    this.documentDescription,
  });

  int? knowledgeCid;
  Category? categoryName;
  String? documentTitle;
  String? documentDescription;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        knowledgeCid: json["KnowledgeCID"],
        categoryName: categoryValues.map[json["CategoryName"]],
        documentTitle: json["DocumentTitle"],
        documentDescription: json["DocumentDescription"],
      );

  Map<String, dynamic> toJson() => {
        "KnowledgeCID": knowledgeCid,
        "CategoryName": categoryValues.reverse![categoryName],
        "DocumentTitle": documentTitle,
        "DocumentDescription": documentDescription,
      };
}

class EnumValues<T> {
  Map<String, T> map;
  Map<T, String>? reverseMap;

  EnumValues(this.map);

  Map<T, String>? get reverse {
    if (reverseMap == null) {
      reverseMap = map.map((k, v) => new MapEntry(v, k));
    }
    return reverseMap;
  }
}
