import 'package:get/get.dart';
import 'package:msm_unify/Api/api_response.dart';
import 'package:msm_unify/model/responseModek/level_of_education_response_model.dart';
import 'package:msm_unify/repo/level_of_education_repo.dart';

class LevelOfEducationViewModel extends GetxController {
  ApiResponse _apiResponse = ApiResponse.initial(message: 'Initialization');

  ApiResponse get apiResponse => _apiResponse;

  onInit() {
    levelOfEducationViewModel();
  }

  Future<void> levelOfEducationViewModel() async {
    _apiResponse = ApiResponse.loading(message: 'Loading');
    update();
    try {
      List<LevelOfEducationResponseModel> response =
          await LevelOfEducationRepo.levelOfEducationRepo();
      print('levelOfEducationRepo=>${response}');
      _apiResponse = ApiResponse.complete(response);
    } catch (e) {
      print(".........>$e");
      _apiResponse = ApiResponse.error(message: 'error');
    }
    update();
  }
}
