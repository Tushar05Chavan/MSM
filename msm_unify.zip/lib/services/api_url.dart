abstract class ApiURLService<T> {
  final String tilesURL =
      'https://unify-qa-api.azurewebsites.net/Dashboard/Tiles?Duration=3';
}
