import 'dart:convert';

import '../model/responseModek/commission_response_model.dart';
import '../services/api_service.dart';
import '../services/api_url.dart';

class CommissionRepo extends ApiURLService {
  Future<List<CommissionResponseModel>> commissionRepo() async {
    var response = await APIService().getResponse(
        url:
            "https://msmunifyapicore.azurewebsites.net/AgentCommission/List?AgentId=9701",
        apitype: APIType.aGet);

    //print('--response ${response}');
    List<CommissionResponseModel> commissionResModel =
        commissionResponseModelFromJson(jsonEncode(response));
    //print('=========repooo${commissionResModel.first}');
    return commissionResModel;
  }
}
