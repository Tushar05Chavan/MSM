import 'dart:convert';

import 'package:msm_unify/model/responseModek/student_document_response_model.dart';
import 'package:msm_unify/services/api_service.dart';
import 'package:msm_unify/services/api_url.dart';

class StudentDocumentRepo extends ApiURLService {
  Future<List<StudentDocumentResponseModel>> studentDocumentRepo() async {
    var response = await APIService().getResponse(
        url:
            "https://msmunifyapicore.azurewebsites.net/Misc/CountryForSearchProgram",
        apitype: APIType.aGet);
    List<StudentDocumentResponseModel> studentDocumentResponseModel =
        studentDocumentResponseModelFromJson(jsonEncode(response));
    print('=========jjjj${studentDocumentResponseModel.first}');
    return studentDocumentResponseModel;
  }
}
