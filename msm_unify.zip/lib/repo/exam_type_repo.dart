import 'dart:convert';

import '../model/responseModek/defferal_detail_response_model.dart';
import '../services/api_service.dart';
import '../services/api_url.dart';

class ExamTypeViewRepo extends ApiURLService {
  Future<List<DetailResModel>> examTypeViewRepo() async {
    var response = await APIService().getResponse(
        url:
            "https://msmunifyapicore.azurewebsites.net/ProgramRequirement/RequirementList?ReqTypeId=1",
        apitype: APIType.aGet);

    print('--res ${response}');
    List<DetailResModel> detailResModel =
        detailResModelFromJson(jsonEncode(response));
    print('=========repooo${detailResModel.first}');
    return detailResModel;
  }
}
