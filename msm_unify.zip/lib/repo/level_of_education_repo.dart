import 'dart:convert';

import 'package:msm_unify/model/responseModek/level_of_education_response_model.dart';
import 'package:msm_unify/services/api_service.dart';
import 'package:msm_unify/services/api_url.dart';

class LevelOfEducationRepo extends ApiURLService {
  static Future<List<LevelOfEducationResponseModel>>
      levelOfEducationRepo() async {
    var response = await APIService().getResponse(
      url:
          "https://msmunifyapicore.azurewebsites.net/StudentSchool/EduLevelForDDLByApplication?ParentType=7&ParentId=107217&SchoolId=undefined",
      apitype: APIType.aGet,
    );
    List<LevelOfEducationResponseModel> levelOfEducationResponseModel =
        levelOfEducationResponseModelFromJson(jsonEncode(response));
    print('=========jjjj${levelOfEducationResponseModel.first}');
    return levelOfEducationResponseModel;
  }
}
