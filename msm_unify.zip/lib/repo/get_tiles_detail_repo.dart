import 'dart:convert';

import 'package:msm_unify/model/responseModek/get_tiles_response_model.dart';
import 'package:msm_unify/services/api_service.dart';
import 'package:msm_unify/services/api_url.dart';

class GetTilesDetailsRepo extends ApiURLService {
  Map<String, String> qParams = {
    'Duration': '3',
  };
  Future<List<TilesResponseModel>> getTilesDetails() async {
    print('rrfgr');
    var response = await APIService().getResponse(
        url:
            "https://unify-qa-api.azurewebsites.net/Dashboard/Tiles?Duration=3",
        apitype: APIType.aGet);
    print('rrfgr');
    print('--res ${response}');
    List<TilesResponseModel> tilesResponseModel =
        tilesResponseModelFromJson(jsonEncode(response));
    print('=========jjjj${tilesResponseModel.first}');
    return tilesResponseModel;
  }
}
